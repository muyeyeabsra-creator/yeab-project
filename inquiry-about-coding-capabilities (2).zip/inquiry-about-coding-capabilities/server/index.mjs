import { createServer } from "node:http";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID, timingSafeEqual } from "node:crypto";

const root = path.dirname(fileURLToPath(import.meta.url));
const distFile = path.resolve(root, "../dist/index.html");
const dataDir = path.join(root, "data");
const dataFile = path.join(dataDir, "project-requests.json");
const port = Number(process.env.PORT || 4179);
const host = process.env.HOST || "127.0.0.1";
const adminToken = process.env.ADMIN_TOKEN || "";
const maxBodyBytes = 32 * 1024;

function send(res, status, payload) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  res.end(JSON.stringify(payload));
}

async function readBody(req) {
  let body = "";
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body) > maxBodyBytes) throw Object.assign(new Error("Payload too large"), { status: 413 });
  }
  try {
    return JSON.parse(body);
  } catch {
    throw Object.assign(new Error("Invalid JSON"), { status: 400 });
  }
}

async function saveProject(project) {
  await mkdir(dataDir, { recursive: true });
  let existing = [];
  try {
    existing = JSON.parse(await readFile(dataFile, "utf8"));
    if (!Array.isArray(existing)) existing = [];
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  const saved = { id: randomUUID(), receivedAt: new Date().toISOString(), ...project };
  existing.push(saved);
  await writeFile(dataFile, `${JSON.stringify(existing, null, 2)}\n`, "utf8");
  return saved;
}

function canViewProjects(req) {
  const remote = req.socket.remoteAddress || "";
  const isLoopback = remote === "127.0.0.1" || remote === "::1" || remote === "::ffff:127.0.0.1";
  if (host === "127.0.0.1" && isLoopback) return true;
  const authorization = req.headers.authorization || "";
  const provided = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
  if (!adminToken || !provided) return false;
  const expectedBytes = Buffer.from(adminToken);
  const providedBytes = Buffer.from(provided);
  return expectedBytes.length === providedBytes.length && timingSafeEqual(expectedBytes, providedBytes);
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);

  if (url.pathname === "/api/health" && req.method === "GET") {
    return send(res, 200, { ok: true, service: "code-tebib-api" });
  }

  if (url.pathname === "/api/admin/requests" && req.method === "GET") {
    if (!canViewProjects(req)) {
      const message = adminToken ? "A valid admin token is required." : "Set ADMIN_TOKEN before exposing the admin inbox to a network.";
      return send(res, adminToken ? 401 : 503, { error: message });
    }
    try {
      let projects = [];
      try {
        projects = JSON.parse(await readFile(dataFile, "utf8"));
        if (!Array.isArray(projects)) projects = [];
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      projects.sort((a, b) => String(b.receivedAt).localeCompare(String(a.receivedAt)));
      return send(res, 200, { ok: true, projects });
    } catch {
      return send(res, 500, { error: "Could not read project requests." });
    }
  }

  if (url.pathname === "/api/projects" && req.method === "POST") {
    try {
      const body = await readBody(req);
      const name = typeof body.name === "string" ? body.name.trim().slice(0, 60) : "";
      const tagline = typeof body.tagline === "string" ? body.tagline.trim().slice(0, 180) : "";
      const email = typeof body.email === "string" ? body.email.trim().slice(0, 120) : "";
      const contactEmail = typeof body.contactEmail === "string" ? body.contactEmail.trim().slice(0, 120) : "";
      const allowedTypes = new Set(["business", "portfolio", "store", "app"]);
      const allowedSections = new Set(["about", "offerings", "work"]);
      if (!name || !tagline || !allowedTypes.has(body.type)) {
        return send(res, 400, { error: "A site name, description, and valid project type are required." });
      }
      if ([email, contactEmail].some((value) => value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))) {
        return send(res, 400, { error: "Please provide a valid email address." });
      }
      const sections = Array.isArray(body.sections)
        ? body.sections.filter((section) => allowedSections.has(section)).slice(0, 3)
        : ["about", "offerings", "work"];
      const saved = await saveProject({
        name,
        tagline,
        email,
        contactEmail,
        type: body.type,
        language: body.language === "am" ? "am" : "en",
        palette: typeof body.palette === "string" ? body.palette.slice(0, 40) : "Forest gold",
        sections,
      });
      return send(res, 201, { ok: true, id: saved.id, receivedAt: saved.receivedAt });
    } catch (error) {
      return send(res, error.status || 500, { error: error.status ? error.message : "Could not save your project request." });
    }
  }

  if (url.pathname.startsWith("/api/")) return send(res, 404, { error: "API route not found." });

  if (req.method === "GET" || req.method === "HEAD") {
    try {
      const html = await readFile(distFile);
      res.writeHead(200, {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-cache",
        "X-Content-Type-Options": "nosniff",
      });
      return res.end(req.method === "HEAD" ? undefined : html);
    } catch {
      return send(res, 503, { error: "Build the frontend first with npm run build." });
    }
  }

  return send(res, 405, { error: "Method not allowed." });
});

server.listen(port, host, () => {
  process.stdout.write(`Code Tebib app and API listening at http://${host}:${port}\n`);
});
