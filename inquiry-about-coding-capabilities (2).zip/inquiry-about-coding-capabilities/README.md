# Code Tebib

Bilingual Amharic and English website for Code Tebib, built with Vite, React 19, TypeScript, and Tailwind CSS 4. Includes a no-code multi-section website starter, a Node.js API for project requests, and a protected owner inbox.

## Run locally

Install dependencies with `npm ci`.

In one terminal, start the API with `npm run api`. In another, start Vite with `npm run dev`. The Vite server forwards `/api` requests to the API on port 4179.

## Build and serve

Run `npm run build`, then `npm start`. The Node server serves the single-file production site and the API at `http://127.0.0.1:4179` by default. Set `PORT` and `HOST` to configure the listener in a deployment environment.

## API

- `GET /api/health` reports whether the API is available.
- `POST /api/projects` accepts a JSON project brief (`name`, `tagline`, reply email, public contact email, project type, language, color palette, and selected sections).
- `GET /api/admin/requests` returns saved requests to the owner inbox at `/admin`.

Requests are appended to `server/data/project-requests.json`. Keep that file private because it can contain contact details. The data directory is excluded from source control.

The builder generates a responsive multi-page website package (`index.html` plus selected About, Services, Work, and Contact pages) in the browser and downloads it as a ZIP. It supports business, portfolio, product-catalogue, and app-introduction layouts. It does not create store checkout or a custom web-app backend; those require a commissioned project. Sending a request stores the brief for Code Tebib.

The owner inbox works without a token while the server is bound to `127.0.0.1`. For a network deployment, set a strong `ADMIN_TOKEN` environment variable and use that token to open `/admin`. Do not expose the admin API without a token.
