import { useEffect, useState } from "react";
import EnglishSite from "./components/EnglishSite";
import AdminInbox from "./components/AdminInbox";
import { getLanguage, LANGUAGE_EVENT, type Language } from "./lib/language";
import Capabilities from "./components/Capabilities";
import CodeShowcase from "./components/CodeShowcase";
import Faq from "./components/Faq";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import Nav from "./components/Nav";
import Playground from "./components/Playground";
import Process from "./components/Process";
import Work from "./components/Work";
import WebsiteBuilder from "./components/WebsiteBuilder";
import { TECH } from "./lib/data";
import { usePrefersReducedMotion } from "./lib/hooks";
import { cn } from "./utils/cn";

function BackToTop() {
  const reduced = usePrefersReducedMotion();
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(window.scrollY > 700);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" })}
      aria-label="ወደ ላይ ተመለስ"
      className={cn(
        "fixed bottom-6 right-6 z-40 grid h-12 w-12 place-items-center border border-gold/60 bg-ink/90 text-gold backdrop-blur transition-all duration-300 hover:bg-gold hover:text-ink",
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
      )}
    >
      <svg className="h-5 w-5" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M8 14V2M3 7l5-5 5 5" />
      </svg>
    </button>
  );
}

export default function App() {
  const [language, setLanguage] = useState<Language>(getLanguage);
  const [pathname] = useState(() => window.location.pathname);

  useEffect(() => {
    const update = (event: Event) => setLanguage((event as CustomEvent<Language>).detail);
    window.addEventListener(LANGUAGE_EVENT, update);
    return () => window.removeEventListener(LANGUAGE_EVENT, update);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = "ltr";
    document.title = language === "am" ? "ኮድ ጠቢብ — ሙሉ ዌብሳይት እጽፋለሁ" : "Code Tebib — From idea to online";
  }, [language]);

  if (pathname === "/admin") return <AdminInbox language={language} />;
  if (language === "en") return <EnglishSite />;

  return (
    <div id="top" className="relative min-h-screen overflow-x-clip bg-ink font-body text-cream">
      {/* የበስተጀርባ ንብርብሮች */}
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0">
        <div className="grid-dark absolute inset-0 opacity-70 [mask-image:radial-gradient(ellipse_80%_60%_at_50%_0%,black,transparent)]" />
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(55% 45% at 72% 0%, rgba(233,184,77,0.08), transparent 60%), radial-gradient(45% 40% at 8% 100%, rgba(63,169,114,0.07), transparent 60%)",
          }}
        />
      </div>

      <Nav />

      <main className="relative z-10">
        <Hero />
        <Marquee items={TECH} />
        <Capabilities />
        <Work />
        <Playground />
        <WebsiteBuilder language="am" />
        <Process />
        <CodeShowcase />
        <Faq />
      </main>

      <div className="relative z-10">
        <Footer />
      </div>

      <BackToTop />

      {/* የቆዳ ሸካራነት (grain) */}
      <div aria-hidden className="grain pointer-events-none fixed inset-0 z-[60] opacity-[0.05] mix-blend-overlay" />
    </div>
  );
}
