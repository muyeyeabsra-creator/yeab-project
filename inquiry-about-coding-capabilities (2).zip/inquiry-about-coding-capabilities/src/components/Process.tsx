import { STEPS } from "../lib/data";
import { Reveal } from "../lib/hooks";
import SectionHead from "./SectionHead";

export default function Process() {
  return (
    <section id="process" className="relative scroll-mt-24 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHead
          no="04"
          label="ሂደት · Process"
          title={
            <>
              እንዴት <span className="text-gold">እሰራለሁ?</span>
            </>
          }
          note="ከጥያቄ እስከ ማስጀመር — አራት ግልጽ ደረጃዎች፣ ያለ ምንም ድንገተኛነት።"
        />

        <div className="relative">
          {/* የሚያገናኝ መስመር */}
          <div
            aria-hidden
            className="absolute left-0 right-0 top-[26px] hidden border-t border-dashed border-cream/15 md:block"
          />
          <div className="grid gap-12 md:grid-cols-4 md:gap-6">
            {STEPS.map((s, i) => (
              <Reveal key={s.no} delay={i * 120}>
                <div className="group relative">
                  <div className="relative z-10 flex h-[52px] w-[52px] items-center justify-center border border-gold/50 bg-ink font-latin text-sm font-bold text-gold transition-all duration-300 group-hover:bg-gold group-hover:text-ink group-hover:shadow-[0_0_30px_rgba(233,184,77,0.35)]">
                    {s.no}
                  </div>
                  <h3 className="mt-6 font-display text-2xl font-bold text-cream">{s.title}</h3>
                  <p className="mt-2.5 text-sm leading-7 text-mist">{s.desc}</p>
                  <span className="mt-4 inline-block border border-cream/15 px-3 py-1 font-latin text-[11px] font-semibold uppercase tracking-[0.18em] text-faint transition-colors duration-300 group-hover:border-gold/50 group-hover:text-gold">
                    {s.time}
                  </span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
