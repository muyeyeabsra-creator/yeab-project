import { useState } from "react";
import type { FormEvent } from "react";
import { PHRASES } from "../lib/data";
import { Reveal } from "../lib/hooks";
import { cn } from "../utils/cn";
import Marquee from "./Marquee";
import SectionHead from "./SectionHead";

const TABS = [
  { id: "counter", label: "ቆጣሪ" },
  { id: "list", label: "ዝርዝር" },
  { id: "color", label: "ቀለም" },
  { id: "hello", label: "ሰላምታ" },
] as const;
type TabId = (typeof TABS)[number]["id"];

/* --- ቆጣሪ --- */
function CounterTab() {
  const [n, setN] = useState(0);
  return (
    <div className="flex flex-col items-center gap-9">
      <p key={n} className="pop font-latin text-8xl font-bold tabular-nums text-cream md:text-9xl">
        {n}
      </p>
      <div className="flex items-center gap-3">
        <button
          onClick={() => setN((v) => v - 1)}
          className="grid h-12 w-12 place-items-center border border-cream/20 text-xl text-cream transition-colors duration-200 hover:border-ember hover:text-ember"
          aria-label="ቀንስ"
        >
          −
        </button>
        <button
          onClick={() => setN(0)}
          className="h-12 border border-cream/20 px-5 text-sm font-semibold text-mist transition-colors duration-200 hover:border-cream hover:text-cream"
        >
          ዳግም ጀምር
        </button>
        <button
          onClick={() => setN((v) => v + 1)}
          className="h-12 bg-gold px-6 font-latin text-sm font-bold text-ink transition-all duration-200 hover:bg-cream active:scale-95"
        >
          +1 ጨምር
        </button>
      </div>
      <p className="font-mono text-xs text-faint">useState(0) — አንድ ጠቅታ፣ አንድ ለውጥ</p>
    </div>
  );
}

/* --- ዝርዝር --- */
type Item = { id: number; t: string; done: boolean };
function ListTab() {
  const [items, setItems] = useState<Item[]>([
    { id: 1, t: "ኮድ መጻፍ መማር", done: true },
    { id: 2, t: "የራሴን ዌብሳይት መስራት", done: false },
    { id: 3, t: "ወደ ኢንተርኔት ማስጀመር", done: false },
  ]);
  const [text, setText] = useState("");

  const add = (e: FormEvent) => {
    e.preventDefault();
    const t = text.trim();
    if (!t) return;
    setItems((v) => [...v, { id: Date.now(), t, done: false }]);
    setText("");
  };

  return (
    <div className="mx-auto max-w-lg">
      <form onSubmit={add} className="flex gap-2">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="አዲስ ተግባር ጻፍ…"
          className="min-w-0 flex-1 border border-cream/20 bg-deep px-4 py-3 text-sm text-cream outline-none transition-colors placeholder:text-faint focus:border-gold"
        />
        <button
          type="submit"
          className="shrink-0 bg-gold px-5 text-sm font-bold text-ink transition-all duration-200 hover:bg-cream active:scale-95"
        >
          ጨምር
        </button>
      </form>
      <ul className="mt-5 space-y-2">
        {items.map((it) => (
          <li
            key={it.id}
            className="flex items-center gap-3 border border-cream/10 bg-deep/70 px-4 py-3 transition-colors duration-200 hover:border-cream/25"
          >
            <button
              onClick={() =>
                setItems((v) => v.map((x) => (x.id === it.id ? { ...x, done: !x.done } : x)))
              }
              aria-label={it.done ? "አጠናቅቋል" : "አላጠናቀቀም"}
              className={cn(
                "grid h-5 w-5 shrink-0 place-items-center border transition-all duration-200",
                it.done ? "border-leaf bg-leaf text-ink" : "border-cream/30 text-transparent hover:border-gold"
              )}
            >
              <svg className="h-3 w-3" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.2">
                <path d="M2 6.5 4.8 9 10 3.5" />
              </svg>
            </button>
            <span
              className={cn(
                "flex-1 text-sm transition-all duration-200",
                it.done ? "text-faint line-through" : "text-cream"
              )}
            >
              {it.t}
            </span>
            <button
              onClick={() => setItems((v) => v.filter((x) => x.id !== it.id))}
              aria-label="ሰርዝ"
              className="text-faint transition-colors duration-200 hover:text-ember"
            >
              <svg className="h-3.5 w-3.5" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M2.5 2.5l7 7M9.5 2.5l-7 7" />
              </svg>
            </button>
          </li>
        ))}
        {items.length === 0 && (
          <li className="border border-dashed border-cream/15 px-4 py-6 text-center text-sm text-faint">
            ዝርዝሩ ባዶ ነው — ከላይ ጻፍና ጨምር!
          </li>
        )}
      </ul>
      <p className="mt-4 font-mono text-xs text-faint">
        {items.filter((x) => !x.done).length} ቀሪ · {items.filter((x) => x.done).length} ተጠናቅቋል
      </p>
    </div>
  );
}

/* --- ቀለም --- */
const PALS = [
  { name: "ተራራ", bg: "#0c1512", card: "#14231c", accent: "#3fa972", text: "#ede6d2" },
  { name: "ገበያ", bg: "#f1ead6", card: "#fbf6e9", accent: "#d5542f", text: "#22301f" },
  { name: "ባህር", bg: "#0e1826", card: "#152238", accent: "#5fb0d8", text: "#e6edf5" },
  { name: "መስቀል", bg: "#1a1208", card: "#271c0c", accent: "#e9b84d", text: "#f3e9cf" },
];
function ColorTab() {
  const [pi, setPi] = useState(0);
  const pal = PALS[pi];
  return (
    <div className="flex flex-col items-center gap-8">
      {/* የድረ-ገጽ ናሙና */}
      <div
        className="w-full max-w-md overflow-hidden border border-cream/15 transition-colors duration-500"
        style={{ backgroundColor: pal.bg }}
      >
        <div className="flex items-center gap-1.5 border-b px-4 py-2.5" style={{ borderColor: `${pal.text}22` }}>
          <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: `${pal.text}44` }} />
          <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: `${pal.text}44` }} />
          <span className="ml-3 h-2 flex-1 rounded-full" style={{ backgroundColor: `${pal.text}22` }} />
        </div>
        <div className="space-y-4 p-6">
          <div className="h-4 w-2/3 transition-colors duration-500" style={{ backgroundColor: pal.accent }} />
          <div className="h-2.5 w-full transition-colors duration-500" style={{ backgroundColor: `${pal.text}33` }} />
          <div className="h-2.5 w-5/6 transition-colors duration-500" style={{ backgroundColor: `${pal.text}33` }} />
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="h-14 transition-colors duration-500" style={{ backgroundColor: pal.card }} />
            <div className="h-14 transition-colors duration-500" style={{ backgroundColor: pal.card }} />
          </div>
          <div
            className="inline-block px-5 py-2 text-sm font-bold transition-colors duration-500"
            style={{ backgroundColor: pal.accent, color: pal.bg }}
          >
            ጀምር →
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {PALS.map((pl, i) => (
          <button
            key={pl.name}
            onClick={() => setPi(i)}
            aria-label={pl.name}
            className={cn(
              "h-10 w-10 rounded-full border-2 transition-all duration-300",
              i === pi ? "scale-110 border-cream" : "scale-100 border-transparent hover:scale-105"
            )}
            style={{ backgroundColor: pl.accent, boxShadow: `inset 0 0 0 4px ${pl.bg}` }}
          />
        ))}
      </div>
      <p className="font-mono text-xs text-faint">
        ገጽታ፡ <span className="text-gold">{pal.name}</span> — አንድ state፣ ሙሉ ገጽ ይለወጣል
      </p>
    </div>
  );
}

/* --- ሰላምታ --- */
function HelloTab() {
  const [name, setName] = useState("");
  const clean = name.trim();
  return (
    <div className="mx-auto max-w-md space-y-7 text-center">
      <p className="font-display text-xl font-bold text-cream md:text-2xl">
        ስምህን ጻፍ — ሰላምታ እሰጥሃለሁ
      </p>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="ለምሳሌ፦ አበበ"
        className="w-full border border-cream/20 bg-deep px-5 py-4 text-center text-lg text-cream outline-none transition-colors placeholder:text-faint focus:border-gold"
      />
      <div key={clean} className="pop min-h-[72px]">
        {clean ? (
          <p className="font-display text-3xl font-extrabold leading-snug text-gold md:text-4xl">
            ሰላም፣ {clean}!
            <span className="mt-1 block text-lg font-semibold text-mist">እንኳን ደህና መጡ።</span>
          </p>
        ) : (
          <p className="pt-3 text-sm text-faint">ገና ስም አልጻፍህም… ፊደል ጨምር እና ተመልከት።</p>
        )}
      </div>
    </div>
  );
}

export default function Playground() {
  const [tab, setTab] = useState<TabId>("counter");
  return (
    <section id="play" className="relative scroll-mt-24">
      <Marquee items={PHRASES} dark={false} />
      <div className="grid-light relative bg-paper py-24 text-ink md:py-32">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <SectionHead
            dark={false}
            no="03"
            label="ማሳያ · Live Playground"
            title={
              <>
                በቀጥታ <span className="text-ember">ሞክረው።</span>
              </>
            }
            note="ይህ ማሳያ አይደለም — እውነተኛ መተግበሪያ ነው። ጠቅታዎችህ ሁሉ በReact state ይሰራሉ።"
          />

          <Reveal>
            <div className="mx-auto max-w-3xl overflow-hidden border border-ink/20 bg-ink text-cream shadow-[0_40px_90px_-30px_rgba(11,18,15,0.55)]">
              {/* ትሮች */}
              <div className="flex border-b border-cream/10">
                {TABS.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTab(t.id)}
                    className={cn(
                      "relative flex-1 py-4 text-sm font-bold transition-colors duration-200",
                      tab === t.id ? "text-gold" : "text-mist hover:text-cream"
                    )}
                  >
                    {t.label}
                    <span
                      className={cn(
                        "absolute inset-x-0 bottom-0 h-[2px] bg-gold transition-transform duration-300",
                        tab === t.id ? "scale-x-100" : "scale-x-0"
                      )}
                    />
                  </button>
                ))}
              </div>

              {/* ይዘት */}
              <div className="min-h-[360px] px-6 py-12 md:px-12">
                {tab === "counter" && <CounterTab />}
                {tab === "list" && <ListTab />}
                {tab === "color" && <ColorTab />}
                {tab === "hello" && <HelloTab />}
              </div>
            </div>
          </Reveal>

          <Reveal delay={150}>
            <p className="mt-6 text-center font-mono text-xs text-ink/50">
              React state · TypeScript · ሰርቨር የለም — ሁሉም በብራውዘርህ ውስጥ ይሰራል
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
