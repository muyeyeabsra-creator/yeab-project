import { useState } from "react";
import { FAQS } from "../lib/data";
import { Reveal } from "../lib/hooks";
import { cn } from "../utils/cn";
import SectionHead from "./SectionHead";

export default function Faq() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" className="relative scroll-mt-24 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid gap-14 lg:grid-cols-12">
          {/* ግራ — ርዕስ እና ጥሪ */}
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-28">
              <SectionHead
                no="06"
                label="ጥያቄ · FAQ"
                title={
                  <>
                    የተጠየቁ{" "}
                    <span className="text-gold">ጥያቄዎች</span>
                  </>
                }
              />
              <Reveal>
                <div className="-mt-4 border border-cream/10 bg-deep p-6 md:-mt-8">
                  <p className="font-display text-lg font-bold text-cream">ሌላ ጥያቄ አለህ?</p>
                  <p className="mt-2 text-sm leading-7 text-mist">
                    ጥያቄህን በቀጥታ ጻፍልኝ — መልሱ ከኮድ ጋር አብሮ ይመጣል።
                  </p>
                  <a
                    href="#contact"
                    className="group mt-5 inline-flex items-center gap-2 text-sm font-bold text-gold"
                  >
                    ወደ አገናኝ ዝለል
                    <svg
                      className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                      viewBox="0 0 16 16"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path d="M2 8h11M9 3l5 5-5 5" />
                    </svg>
                  </a>
                </div>
              </Reveal>
            </div>
          </div>

          {/* ቀኝ — አኮርዲዮን */}
          <div className="lg:col-span-8">
            {FAQS.map((f, i) => (
              <Reveal key={f.q} delay={i * 60}>
                <div className="border-t border-cream/10 last:border-b">
                  <button
                    onClick={() => setOpen(open === i ? -1 : i)}
                    aria-expanded={open === i}
                    className="group flex w-full items-center justify-between gap-6 py-6 text-left"
                  >
                    <span className="flex items-baseline gap-4">
                      <span className="font-latin text-xs font-semibold text-faint">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span
                        className={cn(
                          "font-display text-lg font-bold transition-colors duration-300 md:text-2xl",
                          open === i ? "text-gold" : "text-cream group-hover:text-gold"
                        )}
                      >
                        {f.q}
                      </span>
                    </span>
                    <span
                      className={cn(
                        "grid h-9 w-9 shrink-0 place-items-center border transition-all duration-300",
                        open === i
                          ? "rotate-45 border-gold bg-gold text-ink"
                          : "border-cream/20 text-mist group-hover:border-gold group-hover:text-gold"
                      )}
                    >
                      <svg className="h-4 w-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M8 2v12M2 8h12" />
                      </svg>
                    </span>
                  </button>
                  <div className={cn("acc", open === i && "open")}>
                    <div>
                      <p className="max-w-3xl pb-7 pl-9 text-sm leading-8 text-mist md:text-[15px]">
                        {f.a}
                      </p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
