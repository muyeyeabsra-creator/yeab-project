import { CAPABILITIES } from "../lib/data";
import type { Capability } from "../lib/data";
import { Reveal } from "../lib/hooks";
import SectionHead from "./SectionHead";

function CapIcon({ kind }: { kind: Capability["icon"] }) {
  const common = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.6,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  switch (kind) {
    case "site":
      return (
        <svg viewBox="0 0 24 24" className="h-9 w-9" {...common}>
          <rect x="2.5" y="4" width="19" height="16" rx="1.5" />
          <path d="M2.5 8.5h19" />
          <path d="M5.2 6.3h.01M7.6 6.3h.01" strokeWidth="2.2" />
          <path d="M6 12h6M6 15.5h4" />
          <path d="M15.5 12 18 14l-2.5 2" />
        </svg>
      );
    case "app":
      return (
        <svg viewBox="0 0 24 24" className="h-9 w-9" {...common}>
          <rect x="3" y="3" width="7.5" height="7.5" rx="1" />
          <rect x="13.5" y="3" width="7.5" height="7.5" rx="1" />
          <rect x="3" y="13.5" width="7.5" height="7.5" rx="1" />
          <path d="M17.2 13.5v7.5M13.5 17.2H21" />
        </svg>
      );
    case "design":
      return (
        <svg viewBox="0 0 24 24" className="h-9 w-9" {...common}>
          <path d="M12 2.5 19 9l-5.2 11.5a1.6 1.6 0 0 1-3.6 0L5 9l7-6.5Z" />
          <circle cx="12" cy="10" r="2.2" />
          <path d="M12 12.2V20" />
        </svg>
      );
    case "api":
      return (
        <svg viewBox="0 0 24 24" className="h-9 w-9" {...common}>
          <rect x="3" y="3.5" width="18" height="7" rx="1.5" />
          <rect x="3" y="13.5" width="18" height="7" rx="1.5" />
          <path d="M6.5 7h.01M6.5 17h.01" strokeWidth="2.4" />
          <path d="M14 7h4M14 17h4" />
          <path d="M12 10.5v3" />
        </svg>
      );
    case "care":
      return (
        <svg viewBox="0 0 24 24" className="h-9 w-9" {...common}>
          <path d="M4 16.5a8.5 8.5 0 1 1 16 0" />
          <path d="M12 16.5 16 11" />
          <circle cx="12" cy="16.5" r="1.4" />
          <path d="M5.5 20.5h13" />
        </svg>
      );
  }
}

export default function Capabilities() {
  return (
    <section id="cap" className="relative scroll-mt-24 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHead
          no="01"
          label="አቅም · Capabilities"
          title={
            <>
              ምን <span className="text-gold">እሰራለሁ?</span>
            </>
          }
          note="ከአንድ ሀሳብ እስከ ሙሉ ምርት — እያንዳንዱ ደረጃ በእጄ ይተላለፋል። ስምንቱን ጠቅ አድርገህ አታጣም፤ ዝርዝሩ ይከፈታል።"
        />

        <div>
          {CAPABILITIES.map((c, i) => (
            <Reveal key={c.no} delay={i * 60}>
              <div className="group relative overflow-hidden border-t border-cream/10 last:border-b">
                {/* ከታች ወደ ላይ የሚንሸራተት ብርሃን */}
                <div className="absolute inset-0 translate-y-full bg-panel transition-transform duration-500 ease-[cubic-bezier(0.22,0.7,0.25,1)] group-hover:translate-y-0" />
                {/* የግራ ወርቃማ መስመር */}
                <div className="absolute left-0 top-0 h-full w-[3px] origin-top scale-y-0 bg-gold transition-transform duration-500 group-hover:scale-y-100" />

                <div className="relative z-10 grid items-center gap-4 px-4 py-8 md:grid-cols-[64px_64px_1fr_auto] md:gap-6 md:px-6">
                  <span className="font-latin text-sm font-semibold text-faint transition-colors duration-300 group-hover:text-gold">
                    {c.no}
                  </span>
                  <span className="text-mist transition-all duration-300 group-hover:-translate-y-0.5 group-hover:text-gold">
                    <CapIcon kind={c.icon} />
                  </span>
                  <div>
                    <h3 className="font-display text-2xl font-bold text-cream transition-transform duration-300 group-hover:translate-x-1.5 md:text-3xl">
                      {c.title}{" "}
                      <span className="ml-2 align-middle font-latin text-xs font-medium uppercase tracking-[0.25em] text-faint">
                        {c.latin}
                      </span>
                    </h3>
                    <p className="mt-2 max-w-2xl text-sm leading-7 text-mist">{c.desc}</p>
                    <div className="mt-3.5 flex flex-wrap gap-2">
                      {c.tags.map((t) => (
                        <span
                          key={t}
                          className="border border-cream/15 px-2.5 py-1 font-mono text-[11px] text-cream/70 transition-colors duration-300 group-hover:border-gold/40 group-hover:text-gold"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                  <span className="hidden -translate-x-3 text-gold opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100 md:block">
                    <svg className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                      <path d="M4 12h15M13 6l6 6-6 6" />
                    </svg>
                  </span>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
