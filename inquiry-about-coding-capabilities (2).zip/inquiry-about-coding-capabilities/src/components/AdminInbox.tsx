import { useEffect, useState } from "react";
import type { Language } from "../lib/language";
import LanguageSwitch from "./LanguageSwitch";

type ProjectRequest = {
  id: string;
  receivedAt: string;
  name: string;
  tagline: string;
  type: string;
  language: Language;
  palette: string;
  sections: string[];
  email?: string;
  contactEmail?: string;
};

const labels = {
  en: { title: "Project inbox", subtitle: "Website starter requests sent to Code Tebib.", refresh: "Refresh", token: "Admin token", unlock: "Open inbox", loading: "Loading requests…", empty: "No project requests yet.", error: "Could not load project requests.", setup: "For network deployments, set ADMIN_TOKEN on the server and enter it here.", site: "Website", type: "Type", received: "Received", contact: "Public contact", reply: "Reply email", palette: "Palette", sections: "Sections" },
  am: { title: "የፕሮጀክት ጥያቄዎች", subtitle: "ለCode Tebib የተላኩ የዌብሳይት ጥያቄዎች።", refresh: "አድስ", token: "የAdmin ቁልፍ", unlock: "ጥያቄዎቹን ክፈት", loading: "ጥያቄዎችን በመጫን ላይ…", empty: "እስካሁን የተላኩ ጥያቄዎች የሉም።", error: "የፕሮጀክት ጥያቄዎቹን ማሳየት አልተቻለም።", setup: "በኔትወርክ ላይ ለመጠቀም ADMIN_TOKEN በሰርቨሩ ላይ ያዘጋጁና እዚህ ያስገቡ።", site: "ዌብሳይት", type: "አይነት", received: "የደረሰበት ጊዜ", contact: "ይፋዊ ኢሜይል", reply: "የመልስ ኢሜይል", palette: "ቀለም", sections: "ክፍሎች" },
};

export default function AdminInbox({ language }: { language: Language }) {
  const t = labels[language];
  const [token, setToken] = useState("");
  const [projects, setProjects] = useState<ProjectRequest[]>([]);
  const [status, setStatus] = useState<"loading" | "ready" | "auth" | "error">("loading");

  const loadRequests = async (accessToken = token) => {
    setStatus("loading");
    try {
      const response = await fetch("/api/admin/requests", {
        headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : {},
      });
      if (response.status === 401 || response.status === 503) {
        setStatus("auth");
        return;
      }
      if (!response.ok) throw new Error("Request failed");
      const result = await response.json() as { projects: ProjectRequest[] };
      setProjects(result.projects);
      setStatus("ready");
    } catch {
      setStatus("error");
    }
  };

  useEffect(() => { void loadRequests(""); }, []);

  return <main className="min-h-screen bg-ink px-5 py-10 text-cream md:px-8">
    <div className="mx-auto max-w-6xl">
      <header className="flex flex-wrap items-center justify-between gap-4 border-b border-cream/10 pb-5">
        <a href="/" className="font-display text-lg font-bold text-gold">Code Tebib <span className="text-cream">/ Admin</span></a>
        <LanguageSwitch language={language}/>
      </header>
      <div className="mt-10 flex flex-wrap items-end justify-between gap-5">
        <div><p className="font-mono text-xs uppercase tracking-[.2em] text-gold">ADMIN</p><h1 className="mt-3 font-display text-4xl font-black md:text-5xl">{t.title}</h1><p className="mt-3 text-sm text-mist">{t.subtitle}</p></div>
        {status === "ready" && <button onClick={() => void loadRequests()} className="border border-gold/60 px-4 py-2 text-sm font-semibold text-gold hover:bg-gold hover:text-ink">{t.refresh}</button>}
      </div>

      {status === "auth" && <form onSubmit={(event) => { event.preventDefault(); void loadRequests(token); }} className="mt-8 max-w-lg border border-cream/12 bg-deep p-5 md:p-7"><label htmlFor="admin-token" className="text-sm font-semibold">{t.token}</label><input id="admin-token" type="password" autoComplete="current-password" value={token} onChange={(event) => setToken(event.target.value)} className="mt-2 w-full border border-cream/15 bg-ink px-4 py-3 text-cream outline-none focus:border-gold"/><p className="mt-3 text-xs leading-5 text-faint">{t.setup}</p><button className="mt-4 bg-gold px-5 py-3 text-sm font-bold text-ink">{t.unlock}</button></form>}
      {status === "loading" && <p role="status" className="mt-8 text-sm text-mist">{t.loading}</p>}
      {status === "error" && <div className="mt-8 border border-ember/40 bg-ember/10 p-5 text-sm text-cream">{t.error}<button onClick={() => void loadRequests()} className="ml-3 text-gold underline">{t.refresh}</button></div>}
      {status === "ready" && projects.length === 0 && <p className="mt-8 border border-cream/10 p-6 text-sm text-mist">{t.empty}</p>}
      {status === "ready" && projects.length > 0 && <div className="mt-8 space-y-4">{projects.map((project) => <article key={project.id} className="border border-cream/10 bg-deep p-5 md:p-7"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-xl font-bold">{project.name}</h2><p className="mt-1 text-sm leading-6 text-mist">{project.tagline}</p></div><time className="font-mono text-xs text-faint">{new Date(project.receivedAt).toLocaleString(language === "am" ? "am-ET" : "en-US")}</time></div><dl className="mt-5 grid gap-4 border-t border-cream/10 pt-4 text-sm sm:grid-cols-2 lg:grid-cols-3"><div><dt className="text-xs text-faint">{t.type}</dt><dd className="mt-1">{project.type}</dd></div><div><dt className="text-xs text-faint">{t.contact}</dt><dd className="mt-1">{project.contactEmail || "—"}</dd></div><div><dt className="text-xs text-faint">{t.reply}</dt><dd className="mt-1">{project.email || "—"}</dd></div><div><dt className="text-xs text-faint">{t.palette}</dt><dd className="mt-1">{project.palette || "—"}</dd></div><div className="sm:col-span-2"><dt className="text-xs text-faint">{t.sections}</dt><dd className="mt-1">{Array.isArray(project.sections) ? project.sections.join(" · ") || "—" : "—"}</dd></div></dl></article>)}</div>}
    </div>
  </main>;
}
