import type { ReactNode } from "react";
import { Reveal } from "../lib/hooks";
import { cn } from "../utils/cn";

export default function SectionHead({
  no,
  label,
  title,
  note,
  dark = true,
}: {
  no: string;
  label: string;
  title: ReactNode;
  note?: ReactNode;
  dark?: boolean;
}) {
  return (
    <div className="mb-12 flex flex-col gap-6 md:mb-16 md:flex-row md:items-end md:justify-between">
      <div>
        <Reveal>
          <p
            className={cn(
              "flex items-center gap-3 font-latin text-[11px] font-semibold uppercase tracking-[0.32em]",
              dark ? "text-gold" : "text-ember"
            )}
          >
            <span className={cn("h-px w-10", dark ? "bg-gold/60" : "bg-ember/60")} />
            {no} · {label}
          </p>
        </Reveal>
        <Reveal delay={90}>
          <h2
            className={cn(
              "mt-5 font-display text-4xl font-extrabold leading-[1.08] tracking-tight md:text-6xl",
              dark ? "text-cream" : "text-ink"
            )}
          >
            {title}
          </h2>
        </Reveal>
      </div>
      {note && (
        <Reveal delay={170}>
          <p
            className={cn(
              "max-w-sm text-sm leading-7 md:text-right",
              dark ? "text-mist" : "text-ink/60"
            )}
          >
            {note}
          </p>
        </Reveal>
      )}
    </div>
  );
}
