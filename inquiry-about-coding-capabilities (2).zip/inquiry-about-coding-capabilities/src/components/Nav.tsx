import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import LanguageSwitch from "./LanguageSwitch";

const LINKS = [
  { href: "#cap", label: "አቅም" },
  { href: "#work", label: "ስራዎች" },
  { href: "#play", label: "ማሳያ" },
  { href: "#builder", label: "ዌብሳይት ገንባ" },
  { href: "#process", label: "ሂደት" },
  { href: "#faq", label: "ጥያቄ" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [prog, setProg] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProg(h > 0 ? window.scrollY / h : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-cream/10 bg-ink/85 backdrop-blur-md"
          : "border-b border-transparent bg-transparent"
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-8">
        <a href="#top" className="group flex items-center gap-3">
          <span className="grid h-9 min-w-12 place-items-center border border-gold/60 bg-gold/10 px-1 font-display text-sm font-bold text-gold transition-colors duration-300 group-hover:bg-gold group-hover:text-ink">
            ኮድ
          </span>
          <span className="font-display text-lg font-bold tracking-tight text-cream">
            <span className="text-gold">ጠቢብ</span>
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="group relative text-sm font-medium text-mist transition-colors hover:text-cream"
            >
              {l.label}
              <span className="absolute -bottom-1.5 left-0 h-[2px] w-0 bg-gold transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <LanguageSwitch language="am" />
          <a
            href="#contact"
            className="group relative inline-flex items-center gap-2 overflow-hidden border border-gold/70 px-4 py-2 text-sm font-bold text-gold transition-colors duration-300 hover:text-ink"
          >
            <span className="absolute inset-0 translate-y-full bg-gold transition-transform duration-300 ease-out group-hover:translate-y-0" />
            <span className="relative">እንነጋገር</span>
            <svg
              className="relative h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
              viewBox="0 0 16 16"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M4 12 12 4M6 4h6v6" />
            </svg>
          </a>
        </div>
      </div>
      {/* የንባብ ሂደት መስመር */}
      <div className="h-[2px] w-full bg-cream/5">
        <div
          className="h-full bg-gold transition-[width] duration-150 ease-out"
          style={{ width: `${prog * 100}%` }}
        />
      </div>
    </header>
  );
}
