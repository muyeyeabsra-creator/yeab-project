import { setLanguage, type Language } from "../lib/language";

export default function LanguageSwitch({ language }: { language: Language }) {
  const next = language === "am" ? "en" : "am";
  return (
    <button
      type="button"
      onClick={() => setLanguage(next)}
      aria-label={language === "am" ? "Switch language to English" : "ቋንቋውን ወደ አማርኛ ቀይር"}
      className="border border-cream/20 px-3 py-2 font-latin text-xs font-semibold text-mist transition hover:border-gold hover:text-gold"
    >
      {language === "am" ? "EN" : "አማ"}
    </button>
  );
}
