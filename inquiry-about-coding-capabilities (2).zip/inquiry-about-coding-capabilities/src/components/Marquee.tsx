import { cn } from "../utils/cn";

export default function Marquee({
  items,
  reverse = false,
  dark = true,
  className,
}: {
  items: string[];
  reverse?: boolean;
  dark?: boolean;
  className?: string;
}) {
  const row = [...items, ...items];
  return (
    <div
      className={cn(
        "marquee select-none overflow-hidden border-y py-4",
        dark ? "border-cream/10 bg-deep/60" : "border-ink/10 bg-paper",
        reverse && "marquee-rev",
        className
      )}
    >
      <div className="marquee-track items-center">
        {row.map((it, i) => (
          <span key={i} className="flex items-center">
            <span
              className={cn(
                "whitespace-nowrap px-6 font-latin text-[13px] font-medium uppercase tracking-[0.28em]",
                dark ? "text-cream/60" : "text-ink/60"
              )}
            >
              {it}
            </span>
            <span className={cn("text-xs", dark ? "text-gold" : "text-ember")}>✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
