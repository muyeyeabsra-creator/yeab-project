import { useEffect, useMemo, useState } from "react";
import { SNIPPETS, STATS } from "../lib/data";
import {
  Reveal,
  useCountUp,
  useInView,
  usePrefersReducedMotion,
  useScramble,
} from "../lib/hooks";

/* ---------- በራሱ የሚጽፍ ተርሚናል ---------- */
function TypedTerminal() {
  const reduced = usePrefersReducedMotion();
  const [si, setSi] = useState(0);
  const [p, setP] = useState(0);

  const lines = useMemo(() => {
    let off = 0;
    return SNIPPETS[si].map((toks) => {
      const start = off;
      toks.forEach((t) => (off += t.t.length));
      return { toks, start, end: off };
    });
  }, [si]);

  const total = lines.length ? lines[lines.length - 1].end : 0;
  const done = p >= total;

  useEffect(() => {
    if (reduced) {
      setP(total);
      return;
    }
    if (p >= total) {
      const t = setTimeout(() => {
        setSi((v) => (v + 1) % SNIPPETS.length);
        setP(0);
      }, 3200);
      return () => clearTimeout(t);
    }
    const t = setTimeout(
      () => setP((v) => Math.min(total, v + 1)),
      p > 0 && p % 9 === 0 ? 110 : 17
    );
    return () => clearTimeout(t);
  }, [p, total, reduced]);

  const cursorLine =
    p === 0
      ? 0
      : lines.findIndex((l) => p > l.start && p <= l.end);

  return (
    <div className="relative border border-cream/12 bg-deep shadow-[0_40px_90px_-30px_rgba(0,0,0,0.7)]">
      {/* የተርሚናል አናት */}
      <div className="flex items-center justify-between border-b border-cream/10 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-ember/80" />
          <span className="h-3 w-3 rounded-full bg-gold/80" />
          <span className="h-3 w-3 rounded-full bg-leaf/80" />
        </div>
        <span className="font-mono text-xs text-mist">መልስ.tsx</span>
        <span className="font-latin text-[10px] uppercase tracking-[0.2em] text-faint">
          UTF-8
        </span>
      </div>

      {/* ኮዱ */}
      <div className="min-h-[300px] px-4 py-5 font-mono text-[12.5px] leading-[1.9] md:min-h-[320px]">
        {lines.map((ln, i) => (
          <div key={`${si}-${i}`} className="flex whitespace-pre">
            <span className="w-6 shrink-0 pr-4 text-right text-[10px] leading-[calc(12.5px*1.9)] text-faint/50">
              {i + 1}
            </span>
            <span>
              {ln.toks.map((tok, j) => {
                const tokStart =
                  ln.start + ln.toks.slice(0, j).reduce((a, t) => a + t.t.length, 0);
                if (p <= tokStart) return null;
                const shown = tok.t.slice(0, p - tokStart);
                return (
                  <span key={j} className={tok.c ? `tk-${tok.c}` : "text-cream/90"}>
                    {shown}
                  </span>
                );
              })}
              {(cursorLine === i || (done && i === lines.length - 1)) && (
                <span className="cursor-blink ml-[1px] inline-block h-[15px] w-[8px] translate-y-[3px] bg-gold" />
              )}
            </span>
          </div>
        ))}
      </div>

      {/* የሁኔታ መስመር */}
      <div className="flex items-center justify-between border-t border-cream/10 px-4 py-2.5">
        <span className="font-mono text-[11px] text-faint">TSX · አማርኛ · {si + 1}/{SNIPPETS.length}</span>
        <span
          className={`font-mono text-[11px] transition-colors duration-300 ${
            done ? "text-leaf" : "text-gold"
          }`}
        >
          {done ? "✓ ዝግጁ — build passing" : "ይጻፋል…"}
        </span>
      </div>
    </div>
  );
}

/* ---------- ተንሳፋፊ ፊደላት ---------- */
const GLYPH_SPOTS = [
  { ch: "ሀ", cls: "left-[4%] top-[16%] text-8xl text-gold/[0.06] [--dur:16s]" },
  { ch: "ለ", cls: "left-[42%] top-[8%] text-7xl text-leaf/[0.07] [--dur:13s]" },
  { ch: "ቁ", cls: "right-[6%] top-[12%] text-9xl text-gold/[0.05] [--dur:18s]" },
  { ch: "መ", cls: "left-[8%] bottom-[18%] text-9xl text-leaf/[0.05] [--dur:15s]" },
  { ch: "ገ", cls: "right-[30%] bottom-[10%] text-7xl text-cream/[0.04] [--dur:12s]" },
];

/* ---------- ስታት ---------- */
function Stat({ n, suf, label, start }: { n: number; suf: string; label: string; start: boolean }) {
  const val = useCountUp(n, start);
  return (
    <div className="border-l-2 border-gold/30 pl-4">
      <p className="font-latin text-3xl font-bold text-cream md:text-4xl">
        {val}
        <span className="text-gold">{suf}</span>
      </p>
      <p className="mt-1 text-xs text-mist md:text-sm">{label}</p>
    </div>
  );
}

export default function Hero() {
  const line1 = useScramble("አዎ — ሙሉ ዌብሳይት", 250);
  const line2 = useScramble("ኮድ እጽፋለሁ።", 950);
  const [statsRef, statsIn] = useInView<HTMLDivElement>(0.4);

  return (
    <section className="relative overflow-hidden pt-32 pb-16 md:pt-40 md:pb-24">
      {/* ተንሳፋፊ ፊደላት */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        {GLYPH_SPOTS.map((g, i) => (
          <span
            key={i}
            className={`glyph absolute font-display font-black ${g.cls}`}
            style={{ animationDelay: `${i * -3}s` }}
          >
            {g.ch}
          </span>
        ))}
      </div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-12">
        {/* ግራ — ጥያቄ እና መልስ */}
        <div className="lg:col-span-6">
          <Reveal>
            <div className="inline-flex max-w-full items-center gap-3 rounded-full border border-cream/15 bg-deep/80 py-2.5 pl-3 pr-5">
              <svg className="h-4 w-4 shrink-0 text-gold" viewBox="0 0 20 20" fill="currentColor">
                <path d="M3 4h5v5c0 2.5-1.5 4-4 4.5l-.6-1.6c1.4-.4 2.1-1.1 2.3-2.4H3V4Zm8 0h5v5c0 2.5-1.5 4-4 4.5l-.6-1.6c1.4-.4 2.1-1.1 2.3-2.4H11V4Z" />
              </svg>
              <span className="truncate text-[13px] text-mist md:text-sm">
                «ኮድ መጻፍ ለይ እንዴት ነህ? ሙሉ ዌብሳይት ኮድ ታደርጋለህ?»
              </span>
            </div>
          </Reveal>
          <Reveal delay={60}>
            <p className="mt-3 font-latin text-[11px] font-semibold uppercase tracking-[0.32em] text-faint">
              — የአንተ ጥያቄ · የእኔ መልስ
            </p>
          </Reveal>

          <h1 className="mt-6 font-display text-[clamp(2.5rem,7vw,5rem)] font-black leading-[1.1] tracking-tight text-cream">
            <span className="block">{line1}</span>
            <span className="block text-gold">{line2}</span>
          </h1>

          <Reveal delay={200}>
            <p className="mt-6 max-w-xl text-[15px] leading-8 text-mist md:text-base">
              ይህች ገጽ ራሷ መልሷ ናት። <span className="text-cream">React 19</span>፣{" "}
              <span className="text-cream">TypeScript</span> እና{" "}
              <span className="text-cream">Tailwind CSS</span> በመጠቀም ከጥያቄህ ተወልዳለች — ወደ
              ታች ዝቅ በል፤ ሁሉም ነገር በቀጥታ ይሰራል።
            </p>
          </Reveal>

          <Reveal delay={300}>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <a
                href="#play"
                className="group relative inline-flex items-center gap-2.5 overflow-hidden bg-gold px-7 py-3.5 text-sm font-bold text-ink transition-colors duration-300"
              >
                <span className="absolute inset-0 translate-y-full bg-cream transition-transform duration-300 ease-out group-hover:translate-y-0" />
                <span className="relative">ማሳያውን ሞክር</span>
                <svg
                  className="relative h-4 w-4 transition-transform duration-300 group-hover:translate-y-0.5"
                  viewBox="0 0 16 16"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path d="M8 2v12M3 9l5 5 5-5" />
                </svg>
              </a>
              <a
                href="#builder"
                className="inline-flex items-center gap-2.5 border border-gold/40 px-7 py-3.5 text-sm font-semibold text-gold transition-colors duration-300 hover:bg-gold hover:text-ink"
              >
                የራሴን ዌብሳይት ጀምር
                <span aria-hidden>↗</span>
              </a>
              <a
                href="#code"
                className="inline-flex items-center gap-2.5 border border-cream/25 px-7 py-3.5 text-sm font-semibold text-cream transition-colors duration-300 hover:border-gold hover:text-gold"
              >
                <svg className="h-4 w-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M5.5 4.5 2 8l3.5 3.5M10.5 4.5 14 8l-3.5 3.5" />
                </svg>
                ኮዱን ተመልከት
              </a>
            </div>
          </Reveal>

          <div ref={statsRef} className="mt-12 grid grid-cols-2 gap-x-6 gap-y-8 sm:grid-cols-4">
            {STATS.map((s, i) => (
              <Reveal key={s.label} delay={350 + i * 80}>
                <Stat {...s} start={statsIn} />
              </Reveal>
            ))}
          </div>
        </div>

        {/* ቀኝ — ተርሚናል */}
        <div className="lg:col-span-6">
          <Reveal delay={250}>
            <TypedTerminal />
          </Reveal>
          <Reveal delay={400}>
            <div className="mt-4 flex items-center justify-between px-1">
              <p className="font-mono text-[11px] text-faint">
                ~/ፕሮጀክት — <span className="text-gold">live</span>
              </p>
              <p className="hidden font-mono text-[11px] text-faint sm:block">
                እውነተኛ ኮድ · በቀጥታ ይተየባል
              </p>
            </div>
          </Reveal>
        </div>
      </div>

      {/* ወደ ታች ጥቆሜ */}
      <div className="relative mx-auto mt-16 flex max-w-7xl items-center gap-3 px-5 md:px-8">
        <span className="bob grid h-9 w-9 place-items-center rounded-full border border-cream/20 text-mist">
          <svg className="h-4 w-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M8 2v12M3 9l5 5 5-5" />
          </svg>
        </span>
        <span className="text-xs text-faint">ወደ ታች ዝቅ በል — ማሳያው ይጀምራል</span>
      </div>
    </section>
  );
}
