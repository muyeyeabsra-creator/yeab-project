import type { Tok } from "../lib/data";
import { Reveal } from "../lib/hooks";
import SectionHead from "./SectionHead";

const CHECKS = [
  "ንጹህ እና ለማንበብ የሚቀልል ኮድ",
  "በኮምፖነንት የተከፋፈለ መዋቅር",
  "ለስልክ፣ ለጡባዊ እና ለኮምፒውተር ዝግጁ",
  "ፈጣን — ከ90+ Lighthouse ነጥብ በላይ",
  "የአማርኛ ፊደል (ግእዝ) ትክክለኛ ድጋፍ",
];

/* ኮዱን እንደ tokens በማስቀመጥ የJSX ችግርን እናልፋለን */
const SHOWCASE: Tok[][] = [
  [{ t: "// አንድ ትንሽ ኮምፖነንት — እንዲህ እጽፋለሁ", c: "c" }],
  [{ t: "type", c: "k" }, { t: " ጎብኝ ", c: "f" }, { t: "= { ", c: "p" }, { t: "ስም", c: "f" }, { t: ": ", c: "p" }, { t: "string", c: "k" }, { t: " };", c: "p" }],
  [],
  [{ t: "export function", c: "k" }, { t: " ሰላምታ", c: "f" }, { t: "({ ", c: "p" }, { t: "ጎብኝ", c: "f" }, { t: " }: { ", c: "p" }, { t: "ጎብኝ", c: "f" }, { t: " }) {", c: "p" }],
  [{ t: "  const", c: "k" }, { t: " [", c: "p" }, { t: "ቆጠራ", c: "f" }, { t: ", ", c: "p" }, { t: "ጨምር", c: "f" }, { t: "] = ", c: "p" }, { t: "useState", c: "f" }, { t: "(", c: "p" }, { t: "0", c: "s" }, { t: ");", c: "p" }],
  [],
  [{ t: "  return", c: "k" }, { t: " (", c: "p" }],
  [{ t: "    <", c: "p" }, { t: "section", c: "k" }, { t: " className", c: "f" }, { t: "=", c: "p" }, { t: "\"ሰላም\"", c: "s" }, { t: ">", c: "p" }],
  [{ t: "      <", c: "p" }, { t: "h1", c: "k" }, { t: ">ሰላም፣ {", c: "p" }, { t: "ጎብኝ", c: "f" }, { t: ".", c: "p" }, { t: "ስም", c: "f" }, { t: "}!</", c: "p" }, { t: "h1", c: "k" }, { t: ">", c: "p" }],
  [{ t: "      <", c: "p" }, { t: "button", c: "k" }, { t: " onClick", c: "f" }, { t: "={() => ", c: "p" }, { t: "ጨምር", c: "f" }, { t: "(", c: "p" }, { t: "ቆጠራ", c: "f" }, { t: " + ", c: "p" }, { t: "1", c: "s" }, { t: ")}", c: "p" }],
  [{ t: "        className", c: "f" }, { t: "=", c: "p" }, { t: "\"ወርቃማ-ቁልፍ\"", c: "s" }, { t: ">", c: "p" }],
  [{ t: "        ጠቅ ያድርጉ — {", c: "p" }, { t: "ቆጠራ", c: "f" }, { t: "}", c: "p" }],
  [{ t: "      </", c: "p" }, { t: "button", c: "k" }, { t: ">", c: "p" }],
  [{ t: "    </", c: "p" }, { t: "section", c: "k" }, { t: ">", c: "p" }],
  [{ t: "  );", c: "p" }],
  [{ t: "}", c: "p" }],
];

function CodeWindow() {
  return (
    <div className="border border-cream/12 bg-deep shadow-[0_40px_90px_-30px_rgba(0,0,0,0.7)]">
      <div className="flex items-center justify-between border-b border-cream/10 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-ember/80" />
          <span className="h-3 w-3 rounded-full bg-gold/80" />
          <span className="h-3 w-3 rounded-full bg-leaf/80" />
        </div>
        <span className="font-mono text-xs text-mist">src/components/ሰላምታ.tsx</span>
        <span className="font-latin text-[10px] uppercase tracking-[0.2em] text-faint">TSX</span>
      </div>
      <div className="overflow-x-auto px-5 py-5 font-mono text-[12.5px] leading-[1.9]">
        {SHOWCASE.map((line, i) => (
          <div key={i} className="flex whitespace-pre">
            <span className="w-7 shrink-0 pr-4 text-right text-[10px] leading-[calc(12.5px*1.9)] text-faint/50 select-none">
              {i + 1}
            </span>
            <span>
              {line.length === 0
                ? "\u00A0"
                : line.map((tok, j) => (
                    <span key={j} className={tok.c ? `tk-${tok.c}` : "text-cream/90"}>
                      {tok.t}
                    </span>
                  ))}
            </span>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between border-t border-cream/10 px-4 py-2.5">
        <span className="font-mono text-[11px] text-faint">{SHOWCASE.length} መስመር · 0 ስህተት</span>
        <span className="font-mono text-[11px] text-leaf">✓ prettier · eslint</span>
      </div>
    </div>
  );
}

export default function CodeShowcase() {
  return (
    <section id="code" className="relative scroll-mt-24 border-t border-cream/10 bg-deep/50 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid items-start gap-14 lg:grid-cols-12">
          {/* ግራ — የሚጣበቅ ማብራሪያ */}
          <div className="lg:sticky lg:top-28 lg:col-span-5">
            <SectionHead
              no="05"
              label="ኮድ · Under the Hood"
              title={
                <>
                  እንዲህ <span className="text-gold">እጽፋለሁ።</span>
                </>
              }
            />
            <Reveal>
              <p className="-mt-6 max-w-md text-sm leading-8 text-mist md:-mt-8">
                ኮድ ለማሽን ብቻ አይደለም — ለሰው ልጅም ይነበባል። ተለዋዋጮች በአማርኛ ስም እንኳ ይሆናሉ፤
                ምክንያቱም TypeScript የግእዝ ፊደላትን ይቀበላል። ዋናው መርህ ግን ግልጽነት ነው።
              </p>
            </Reveal>
            <ul className="mt-8 space-y-4">
              {CHECKS.map((c, i) => (
                <Reveal key={c} delay={i * 80}>
                  <li className="flex items-center gap-3.5">
                    <span className="grid h-6 w-6 shrink-0 place-items-center border border-gold/50 bg-gold/10 text-gold">
                      <svg className="h-3.5 w-3.5" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.2">
                        <path d="M2 6.5 4.8 9 10 3.5" />
                      </svg>
                    </span>
                    <span className="text-sm text-cream/85">{c}</span>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>

          {/* ቀኝ — የኮድ መስኮት */}
          <div className="lg:col-span-7">
            <Reveal delay={120}>
              <CodeWindow />
            </Reveal>
            <Reveal delay={220}>
              <div className="mt-5 grid grid-cols-3 gap-3">
                {[
                  { v: "19", l: "React ቅርጽ" },
                  { v: "5.9", l: "TypeScript" },
                  { v: "4.1", l: "Tailwind" },
                ].map((x) => (
                  <div
                    key={x.l}
                    className="border border-cream/10 bg-ink px-4 py-4 text-center transition-colors duration-300 hover:border-gold/40"
                  >
                    <p className="font-latin text-2xl font-bold text-gold">{x.v}</p>
                    <p className="mt-1 text-xs text-mist">{x.l}</p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
