import { Reveal } from "../lib/hooks";

const CONTACTS = [
  { label: "ኢሜይል", value: "selam@kodtebib.et", href: "mailto:selam@kodtebib.et" },
  { label: "ቴሌግራም", value: "@kodtebib", href: "#contact" },
  { label: "አድራሻ", value: "አዲስ አበባ · ከየትኛውም ቦታ", href: "#contact" },
];

export default function Footer() {
  return (
    <footer id="contact" className="relative scroll-mt-24 border-t border-cream/10">
      <div className="mx-auto max-w-7xl px-5 py-24 md:px-8 md:py-32">
        <Reveal>
          <p className="flex items-center gap-3 font-latin text-[11px] font-semibold uppercase tracking-[0.32em] text-gold">
            <span className="h-px w-10 bg-gold/60" />
            07 · አገናኝ · Contact
          </p>
        </Reveal>

        <Reveal delay={90}>
          <h2 className="mt-6 font-display text-[clamp(3rem,10vw,7.5rem)] font-black leading-[0.98] tracking-tight text-cream">
            ፕሮጀክት
            <br />
            <span className="text-gold">አለህ?</span>
          </h2>
        </Reveal>

        <Reveal delay={180}>
          <a href="mailto:selam@kodtebib.et" className="group mt-10 inline-block">
            <span className="relative block overflow-hidden font-display text-3xl font-bold leading-tight text-gold md:text-5xl">
              <span className="block transition-transform duration-300 ease-out group-hover:-translate-y-full">
                እንነጋገር →
              </span>
              <span className="absolute inset-0 block translate-y-full text-cream transition-transform duration-300 ease-out group-hover:translate-y-0">
                እንነጋገር →
              </span>
            </span>
            <span className="mt-3 block h-[3px] w-full origin-left scale-x-0 bg-gold transition-transform duration-500 group-hover:scale-x-100" />
          </a>
        </Reveal>

        {/* አገናኝ መረጃ */}
        <div className="mt-16 grid gap-px overflow-hidden border border-cream/10 bg-cream/10 sm:grid-cols-3">
          {CONTACTS.map((c, i) => (
            <Reveal key={c.label} delay={i * 90} className="bg-ink">
              <a
                href={c.href}
                className="group block h-full bg-ink p-6 transition-colors duration-300 hover:bg-panel"
              >
                <p className="font-latin text-[10px] font-semibold uppercase tracking-[0.28em] text-faint transition-colors group-hover:text-gold">
                  {c.label}
                </p>
                <p className="mt-2 text-sm font-semibold text-cream md:text-base">{c.value}</p>
              </a>
            </Reveal>
          ))}
        </div>
      </div>

      {/* የግርጌ መስመር */}
      <div className="border-t border-cream/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-5 py-6 text-xs text-faint sm:flex-row md:px-8">
          <p>© 2026 ኮድ ጠቢብ · ሁሉም መብት የተጠበቀ ነው</p>
          <p className="flex items-center gap-2">
            <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-leaf" />
            ሙሉ ዌብሳይት — በReact 19 እና በTailwind CSS 4 የተሰራ
          </p>
        </div>
      </div>
    </footer>
  );
}
