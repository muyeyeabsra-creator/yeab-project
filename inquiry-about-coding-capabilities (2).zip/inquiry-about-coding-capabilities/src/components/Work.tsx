import { PROJECTS } from "../lib/data";
import type { Project } from "../lib/data";
import { Reveal } from "../lib/hooks";
import SectionHead from "./SectionHead";

function Cover({ p }: { p: Project }) {
  if (p.key === "buna") {
    return (
      <div className="absolute inset-0 bg-gradient-to-br from-gold via-gold/70 to-ember/80">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "repeating-linear-gradient(45deg, rgba(11,18,15,0.25) 0 10px, transparent 10px 22px)",
          }}
        />
        {/* የቡና ስኒ */}
        <svg className="absolute right-6 top-6 h-16 w-16 text-ink/40 transition-transform duration-500 group-hover:-rotate-12" viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M10 18h22v14a8 8 0 0 1-8 8H18a8 8 0 0 1-8-8V18Z" />
          <path d="M32 21h4a5 5 0 0 1 0 10h-4M14 12c0-2 2-2 2-4M21 12c0-2 2-2 2-4M28 12c0-2 2-2 2-4" />
        </svg>
      </div>
    );
  }
  if (p.key === "gebya") {
    const bars = [42, 68, 52, 85, 60, 92, 74];
    return (
      <div className="absolute inset-0 bg-panel">
        <div className="absolute inset-0 grid-light opacity-30" />
        <div className="absolute inset-x-6 bottom-0 flex h-3/4 items-end gap-2.5">
          {bars.map((h, i) => (
            <div
              key={i}
              className={`flex-1 origin-bottom transition-transform duration-500 group-hover:scale-y-110 ${
                i % 3 === 0 ? "bg-gold/70" : i % 3 === 1 ? "bg-leaf/60" : "bg-cream/20"
              }`}
              style={{ height: `${h}%`, transitionDelay: `${i * 40}ms` }}
            />
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className="absolute inset-0 bg-leaf/25">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: "radial-gradient(rgba(237,230,210,0.18) 1.5px, transparent 1.5px)",
          backgroundSize: "22px 22px",
        }}
      />
      <svg className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 text-cream/25 transition-transform duration-700 group-hover:rotate-45" viewBox="0 0 160 160" fill="none" stroke="currentColor">
        <circle cx="80" cy="80" r="70" strokeWidth="1.5" />
        <circle cx="80" cy="80" r="48" strokeWidth="1.5" strokeDasharray="6 8" />
        <circle cx="80" cy="80" r="26" strokeWidth="1.5" />
        <path d="M80 10v28M80 122v28M10 80h28M122 80h28" strokeWidth="1.5" />
      </svg>
    </div>
  );
}

export default function Work() {
  return (
    <section id="work" className="relative scroll-mt-24 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHead
          no="02"
          label="ስራዎች · Selected Work"
          title={
            <>
              ናሙና <span className="text-gold">ፕሮጀክቶች</span>
            </>
          }
          note="እነዚህ የዲዛይን ማሳያ ምሳሌዎች ናቸው፤ ከማተምህ በፊት በእውነተኛ ሥራዎችህ ተካቸው። ሽፋኖቹ በCSS ብቻ የተሳሉ ናቸው።"
        />

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {PROJECTS.map((p, i) => (
            <Reveal key={p.key} delay={i * 110}>
              <article className="group cursor-pointer border border-cream/10 bg-deep transition-all duration-300 hover:-translate-y-2 hover:border-gold/50 hover:shadow-[0_30px_60px_-25px_rgba(0,0,0,0.8)]">
                <div className="relative h-52 overflow-hidden border-b border-cream/10">
                  <Cover p={p} />
                  <span className="absolute -bottom-7 -left-2 font-display text-[8.5rem] font-black leading-none text-ink/30 transition-transform duration-500 origin-bottom-left group-hover:scale-110 group-hover:-rotate-3">
                    {p.letter}
                  </span>
                </div>
                <div className="flex items-start justify-between gap-4 p-6">
                  <div>
                    <p className="font-latin text-[11px] font-semibold uppercase tracking-[0.22em] text-faint">
                      {p.year} · {p.tags.join(" / ")}
                    </p>
                    <h3 className="mt-2.5 font-display text-2xl font-bold text-cream transition-colors duration-300 group-hover:text-gold">
                      {p.title}
                    </h3>
                    <p className="mt-2 text-sm leading-6 text-mist">{p.sub}</p>
                  </div>
                  <span className="mt-1 grid h-10 w-10 shrink-0 place-items-center rounded-full border border-cream/15 text-cream/60 transition-all duration-300 group-hover:rotate-45 group-hover:border-gold group-hover:text-gold">
                    <svg className="h-4 w-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8">
                      <path d="M4 12 12 4M6 4h6v6" />
                    </svg>
                  </span>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        {/* ትልቅ ጥቅስ */}
        <Reveal delay={150}>
          <figure className="mt-20 border-y border-cream/10 py-14 text-center">
            <svg className="mx-auto h-8 w-8 text-gold" viewBox="0 0 24 24" fill="currentColor">
              <path d="M4 5h6v6c0 3.2-1.8 5.4-5 6.3l-.8-2c2-.6 3-1.7 3.2-3.7H4V5Zm10 0h6v6c0 3.2-1.8 5.4-5 6.3l-.8-2c2-.6 3-1.7 3.2-3.7H14V5Z" />
            </svg>
            <blockquote className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-snug text-cream md:text-5xl">
              ከአንድ ጥያቄ — <span className="text-gold">ሙሉ ድረ-ገጽ።</span>
            </blockquote>
            <figcaption className="mt-5 font-latin text-xs uppercase tracking-[0.3em] text-faint">
              የዚህች ገጽ ታሪክ · 2026
            </figcaption>
          </figure>
        </Reveal>
      </div>
    </section>
  );
}
