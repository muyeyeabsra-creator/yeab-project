import { useEffect, useState } from "react";
import LanguageSwitch from "./LanguageSwitch";
import WebsiteBuilder from "./WebsiteBuilder";
import { Reveal, useCountUp, useInView, usePrefersReducedMotion, useScramble } from "../lib/hooks";

const services = [
  { title: "Business websites", latin: "Websites", desc: "Fast, polished business and landing pages that look right on every device.", tags: ["React", "Tailwind", "SEO"] },
  { title: "Web applications", latin: "Web Apps", desc: "Complete apps with dashboards, stores, sign-in, and databases.", tags: ["TypeScript", "Node.js", "PostgreSQL"] },
  { title: "UI / UX design", latin: "Design", desc: "From idea to interface: carefully considered color, typography, and layout.", tags: ["Figma", "Prototype", "Design System"] },
  { title: "API & backend", latin: "Backend", desc: "Fast, secure server-side systems designed to grow with your product.", tags: ["REST", "GraphQL", "Auth"] },
  { title: "Care & performance", latin: "Care", desc: "Speed improvements, bug fixes, maintenance, and ongoing support.", tags: ["Performance", "A11y", "Support"] },
];

const projects = [
  { letter: "B", title: "Buna House", desc: "An online menu, reservations, and ordering system for an Addis Ababa cafe.", year: "2025", tags: ["React", "Stripe", "CMS"], style: "from-gold via-gold/70 to-ember/80" },
  { letter: "G", title: "Gebya Dashboard", desc: "A dashboard that lets sellers track their sales in real time.", year: "2025", tags: ["TypeScript", "Charts", "API"], style: "from-panel via-panel to-leaf/30" },
  { letter: "T", title: "Terara Learning", desc: "A portal where students follow courses and teachers manage learning.", year: "2024", tags: ["Next.js", "Auth", "PostgreSQL"], style: "from-leaf/50 via-panel to-ink" },
];

const steps = [
  ["01", "Listen", "We start with your questions: what are we building, who is it for, and what should it do?", "Day 1"],
  ["02", "Design", "We shape the colors, typography, and layout before development begins.", "Days 2–3"],
  ["03", "Build", "React and TypeScript: clean, fast, and ready for phones and computers.", "Week 1–2"],
  ["04", "Launch", "We put it online, set up the domain, tune performance, and plan ongoing care.", "Launch day"],
];

const faqs = [
  ["How good are you at writing code?", "In short: very good. This page is built with React 19, TypeScript, and Tailwind CSS 4. I write code that is readable, easy to change, and fast."],
  ["Can you build a complete website, front to back?", "Yes. I can handle the frontend, backend, sign-in, payment integration, and launch. Try the interactive playground above to see working React examples."],
  ["How long does a project take?", "A one-page site can take 2–3 days; a mid-sized business site usually takes 1–2 weeks. Larger web apps depend on the plan. I’ll give you a clear timeline before we begin."],
  ["Can you help from design through launch?", "Yes. We start with your idea, choose the visual direction, build the site, connect a domain, launch it, and provide maintenance and support afterward."],
  ["How do I get started?", "Click “Let’s talk” below or send me your question directly. Tell me “Build me a complete website” and we can start planning today."],
];

const tech = ["React", "TypeScript", "Tailwind CSS", "Node.js", "PostgreSQL", "GraphQL", "Vite", "Figma", "Git", "REST API", "Next.js", "Amharic UI"];
const sampleCode = `// A small component—written with care
type Visitor = { name: string };

export function Greeting({ visitor }: { visitor: Visitor }) {
  return (
    <section className="hello">
      <h1>Hello, {visitor.name}!</h1>
      <button onClick={() => alert("Welcome!")}>
        Say hello
      </button>
    </section>
  );
}`;
const swatches = ["#e9b84d", "#3fa972", "#d5542f", "#ede6d2", "#6995e8", "#db75a2"];
type Demo = "counter" | "list" | "color" | "greeting";

function Stat({ value, suffix = "", label }: { value: number; suffix?: string; label: string }) {
  const [ref, inView] = useInView<HTMLDivElement>(0.4);
  const count = useCountUp(value, inView);
  return <div ref={ref} className="border-l-2 border-gold/30 pl-3"><p className="font-latin text-2xl font-bold text-cream md:text-3xl">{count}{suffix}</p><p className="mt-1 text-xs text-mist">{label}</p></div>;
}

function BackToTop() {
  const reduced = usePrefersReducedMotion();
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 700);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return <button onClick={() => window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" })} aria-label="Back to top" className={`fixed bottom-6 right-6 z-40 grid h-12 w-12 place-items-center border border-gold/60 bg-ink/90 text-gold backdrop-blur transition-all duration-300 hover:bg-gold hover:text-ink ${visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}>↑</button>;
}

function EnglishPlayground() {
  const [demo, setDemo] = useState<Demo>("counter");
  const [count, setCount] = useState(0);
  const [items, setItems] = useState([{ id: 1, text: "Sketch the homepage", done: true }, { id: 2, text: "Choose the color palette", done: false }, { id: 3, text: "Build and launch", done: false }]);
  const [color, setColor] = useState(swatches[0]);
  const [name, setName] = useState("friend");
  const tabs: [Demo, string][] = [["counter", "Counter"], ["list", "Checklist"], ["color", "Colors"], ["greeting", "Greeting"]];
  return <div className="border border-cream/15 bg-deep">
    <div className="flex flex-wrap gap-2 border-b border-cream/10 p-4">{tabs.map(([key, label]) => <button key={key} onClick={() => setDemo(key)} className={`px-4 py-2 text-sm transition ${demo === key ? "bg-gold font-bold text-ink" : "text-mist hover:text-cream"}`}>{label}</button>)}</div>
    <div className="min-h-56 p-6 md:p-8">
      {demo === "counter" && <div className="text-center"><p className="font-latin text-6xl font-bold" style={{ color }}>{count}</p><div className="mt-5 flex justify-center gap-3"><button className="border border-cream/20 px-4 py-2 hover:border-gold" onClick={() => setCount((n) => n - 1)} aria-label="Decrease">−</button><button className="border border-cream/20 px-4 py-2 text-sm hover:border-gold" onClick={() => setCount(0)}>Reset</button><button className="border border-cream/20 px-4 py-2 text-sm hover:border-gold" onClick={() => setCount((n) => n + 1)}>+1 Add</button></div><p className="mt-4 font-mono text-xs text-faint">useState(0) · One click, one change</p></div>}
      {demo === "list" && <div className="mx-auto max-w-lg space-y-3">{items.map((item) => <label key={item.id} className="flex items-center gap-3 border border-cream/10 p-3 text-sm"><input type="checkbox" checked={item.done} onChange={() => setItems((all) => all.map((x) => x.id === item.id ? { ...x, done: !x.done } : x))} className="accent-[#e9b84d]"/><span className={item.done ? "text-mist line-through" : "text-cream"}>{item.text}</span><button type="button" className="ml-auto text-faint hover:text-ember" aria-label={`Remove ${item.text}`} onClick={() => setItems((all) => all.filter((x) => x.id !== item.id))}>×</button></label>)}<button onClick={() => setItems((all) => [...all, { id: Date.now(), text: `New task ${all.length + 1}`, done: false }])} className="text-sm font-semibold text-gold">+ Add a task</button></div>}
      {demo === "color" && <div className="flex flex-col items-center gap-5"><div className="grid h-24 w-full max-w-md place-items-center border border-cream/10 font-mono text-sm" style={{ backgroundColor: color, color: "#0b120f" }}>{color}</div><div className="flex flex-wrap justify-center gap-3">{swatches.map((swatch) => <button key={swatch} onClick={() => setColor(swatch)} aria-label={`Choose ${swatch}`} className="h-9 w-9 border-2 border-cream/20 transition hover:scale-110" style={{ backgroundColor: swatch }}/>)}</div></div>}
      {demo === "greeting" && <div className="mx-auto max-w-md text-center"><label className="block text-left text-sm text-mist" htmlFor="visitor-name">Your name</label><input id="visitor-name" value={name} onChange={(event) => setName(event.target.value)} className="mt-2 w-full border border-cream/15 bg-ink px-4 py-3 text-cream outline-none focus:border-gold"/><p className="mt-8 font-display text-3xl font-bold">Hello, <span className="text-gold">{name || "friend"}</span>!</p></div>}
    </div>
    <div className="border-t border-cream/10 px-5 py-3 font-mono text-xs text-faint">React state · TypeScript · No server—the demo runs in your browser</div>
  </div>;
}

function SectionHeading({ no, label, title, note }: { no: string; label: string; title: string; note?: string }) {
  return <Reveal className="mb-12 md:mb-16"><div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between"><div><p className="flex items-center gap-3 font-latin text-[11px] font-semibold uppercase tracking-[.28em] text-gold"><span className="h-px w-10 bg-gold/60"/>{no} · {label}</p><h2 className="mt-5 font-display text-4xl font-extrabold leading-tight tracking-tight md:text-6xl">{title}</h2></div>{note && <p className="max-w-sm text-sm leading-7 text-mist md:text-right">{note}</p>}</div></Reveal>;
}

export default function EnglishSite() {
  const [openFaq, setOpenFaq] = useState(0);
  const headlineFirst = useScramble("Yes — I build", 220);
  const headlineSecond = useScramble("complete websites.", 720);
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const update = () => {
      setScrolled(window.scrollY > 24);
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(height > 0 ? window.scrollY / height : 0);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  return <div id="top" className="relative min-h-screen overflow-x-clip bg-ink font-body text-cream">
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0"><div className="grid-dark absolute inset-0 opacity-70 [mask-image:radial-gradient(ellipse_80%_60%_at_50%_0%,black,transparent)]"/><div className="absolute inset-0" style={{ background: "radial-gradient(55% 45% at 72% 0%, rgba(233,184,77,0.08), transparent 60%), radial-gradient(45% 40% at 8% 100%, rgba(63,169,114,0.07), transparent 60%)" }}/></div>
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${scrolled ? "border-b border-cream/10 bg-ink/85 backdrop-blur-md" : "border-b border-transparent bg-transparent"}`}><div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-8"><a href="#top" className="group flex items-center gap-3"><span className="grid h-9 min-w-12 place-items-center border border-gold/60 bg-gold/10 px-1 font-latin text-xs font-bold text-gold transition-colors group-hover:bg-gold group-hover:text-ink">Code</span><span className="font-display text-lg font-bold text-gold">Tebib</span></a><nav className="hidden items-center gap-6 text-sm text-mist lg:flex"><a href="#cap" className="hover:text-cream">Services</a><a href="#work" className="hover:text-cream">Work</a><a href="#play" className="hover:text-cream">Demo</a><a href="#builder" className="hover:text-cream">Build</a><a href="#process" className="hover:text-cream">Process</a><a href="#faq" className="hover:text-cream">FAQ</a></nav><div className="flex items-center gap-2"><LanguageSwitch language="en"/><a href="#contact" className="border border-gold/70 px-4 py-2 text-sm font-bold text-gold hover:bg-gold hover:text-ink">Let’s talk ↗</a></div></div><div className="h-[2px] w-full bg-cream/5"><div className="h-full bg-gold transition-[width] duration-150" style={{ width: `${progress * 100}%` }}/></div></header>

    <main className="relative z-10">
      <section className="relative overflow-hidden pb-16 pt-32 md:pb-24 md:pt-40"><div aria-hidden className="pointer-events-none absolute inset-0 opacity-40"><div className="grid-dark absolute inset-0"/><span className="glyph absolute left-[6%] top-[20%] font-display text-8xl text-gold/[0.06] [--dur:16s]">C</span><span className="glyph absolute right-[8%] top-[14%] font-mono text-7xl text-leaf/[0.08] [--dur:13s]">&lt;/&gt;</span><span className="glyph absolute bottom-[18%] right-[40%] font-mono text-5xl text-cream/[0.05] [--dur:18s]">01</span></div><div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-12"><div className="lg:col-span-6"><Reveal><p className="inline-flex rounded-full border border-cream/15 bg-deep/80 px-4 py-2 text-sm text-mist">“Can you build me a complete website?”</p><p className="mt-4 font-latin text-[11px] font-semibold uppercase tracking-[.28em] text-faint">— Your question · My answer</p><h1 className="mt-6 font-display text-[clamp(2.6rem,7vw,5rem)] font-black leading-[1.1] tracking-tight">{headlineFirst}<br/><span className="text-gold">{headlineSecond}</span></h1><p className="mt-6 max-w-xl text-base leading-8 text-mist">This page is the answer. Built with React 19, TypeScript, and Tailwind CSS—starting from your idea. Scroll down and explore the working demos.</p><div className="mt-9 flex flex-wrap gap-3"><a href="#play" className="bg-gold px-6 py-3.5 text-sm font-bold text-ink transition hover:-translate-y-1 hover:bg-cream">Try the demo ↓</a><a href="#builder" className="border border-gold/50 px-6 py-3.5 text-sm font-semibold text-gold transition hover:-translate-y-1 hover:bg-gold hover:text-ink">Build a website ↗</a><a href="#code" className="border border-cream/25 px-6 py-3.5 text-sm font-semibold transition hover:-translate-y-1 hover:border-gold hover:text-gold">‹ › View the code</a></div><div className="mt-12 grid grid-cols-2 gap-6 sm:grid-cols-4"><Stat value={5} label="Service areas"/><Stat value={2} label="Languages"/><Stat value={4} label="Website types"/><Stat value={3} label="Color palettes"/></div></Reveal></div><div className="lg:col-span-6"><Reveal delay={220}><div className="border border-cream/12 bg-deep shadow-[0_40px_90px_-30px_rgba(0,0,0,0.7)] transition-transform duration-500 hover:-translate-y-1"><div className="flex items-center justify-between border-b border-cream/10 px-4 py-3"><div className="flex gap-2"><i className="h-3 w-3 rounded-full bg-ember/80"/><i className="h-3 w-3 rounded-full bg-gold/80"/><i className="h-3 w-3 rounded-full bg-leaf/80"/></div><span className="font-mono text-xs text-mist">Answer.tsx</span><span className="font-mono text-[10px] tracking-widest text-faint">UTF-8</span></div><pre className="min-h-72 overflow-x-auto px-5 py-6 font-mono text-xs leading-8 md:px-7 md:text-sm"><span className="text-faint">1  // Your question: “Can you build a complete site?”</span>{"\n"}<span className="text-gold">2  const</span> answer = {'{'}{"\n"}   name: <span className="text-leaf">"Code Tebib"</span>,{"\n"}   stack: [<span className="text-leaf">"React"</span>, <span className="text-leaf">"TypeScript"</span>],{"\n"}   outcome: <span className="text-leaf">"Your idea, online"</span>{"\n"}{'}'};{"\n\n"}<span className="text-gold">function</span> build() {'{'}{"\n"}   <span className="text-gold">return</span> &lt;CompleteWebsite /&gt;;{"\n"}{'}'}</pre><div className="flex items-center justify-between border-t border-cream/10 px-4 py-3 font-mono text-[11px]"><span className="text-faint">TSX · English · Amharic</span><span className="text-leaf">✓ Build passing</span></div></div><p className="mt-4 font-mono text-[11px] text-faint">~/project — <span className="text-gold">live</span><span className="float-right">Real code · Typed in real time</span></p></Reveal></div></div><div className="relative mx-auto mt-12 flex max-w-7xl items-center gap-3 px-5 md:px-8"><span className="bob grid h-9 w-9 place-items-center rounded-full border border-cream/20 text-mist">↓</span><span className="text-xs text-faint">Scroll down — the interactive demos start below</span></div></section>

      <div className="marquee overflow-hidden border-y border-cream/10 py-4" aria-label="Technologies"> <div className="marquee-track">{[...tech, ...tech].map((item, i) => <span key={`${item}-${i}`} className="mx-5 whitespace-nowrap font-latin text-sm text-mist">{item}<span className="ml-10 text-gold">✦</span></span>)}</div></div>

      <section id="cap" className="scroll-mt-24 mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"><SectionHeading no="01" label="Capabilities" title="What can I build?" note="From the first idea to a complete product—I can help at every step."/><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{services.map((service, i) => <Reveal key={service.title} delay={i * 75}><article className="group h-full border border-cream/10 bg-deep p-6 transition duration-300 hover:-translate-y-1 hover:border-gold/40"><div className="flex items-center justify-between"><span className="font-mono text-xs text-gold">0{i + 1}</span><span className="text-xs uppercase tracking-widest text-faint">{service.latin}</span></div><h3 className="mt-8 text-xl font-bold">{service.title}</h3><p className="mt-3 min-h-14 text-sm leading-7 text-mist">{service.desc}</p><div className="mt-5 flex flex-wrap gap-2">{service.tags.map((tag) => <span key={tag} className="border border-cream/10 px-2 py-1 font-mono text-[10px] text-faint">{tag}</span>)}</div></article></Reveal>)}</div></section>

      <section id="work" className="scroll-mt-24 border-y border-cream/10 bg-deep/50"><div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"><SectionHeading no="02" label="Selected work" title="Project examples" note="These are design concepts for the portfolio layout. Replace them with your completed client work before publishing."/><div className="grid gap-5 md:grid-cols-3">{projects.map((project, i) => <Reveal key={project.title} delay={i * 90}><article className="group h-full overflow-hidden border border-cream/10 transition duration-300 hover:-translate-y-1 hover:border-gold/40"><div className={`relative grid aspect-[1.45] place-items-center overflow-hidden bg-gradient-to-br ${project.style}`}><div className="grid-light absolute inset-0 opacity-20"/><span className="relative font-display text-8xl font-black text-ink/40 transition duration-500 group-hover:scale-110">{project.letter}</span><span className="absolute bottom-4 left-4 font-mono text-xs text-cream/70">{project.year} · {project.tags.join(" / ")}</span><span className="absolute right-4 top-4 font-mono text-xs text-cream/50">0{i + 1}</span></div><div className="p-5"><h3 className="text-xl font-bold">{project.title}</h3><p className="mt-2 text-sm leading-6 text-mist">{project.desc}</p></div></article></Reveal>)}</div><Reveal delay={180}><figure className="mt-14 border-l-2 border-gold/50 py-2 pl-6"><blockquote className="font-display text-2xl font-bold md:text-3xl">One question. A complete website.</blockquote><figcaption className="mt-3 font-mono text-xs text-faint">The story behind this page · 2026</figcaption></figure></Reveal></div></section>

      <div className="marquee overflow-hidden border-b border-cream/10 py-4"><div className="marquee-track marquee-rev">{["A complete website", "From one question", "Fast, thoughtful code", "Amharic and English", "Made with care", "Ready for mobile", ...["A complete website", "From one question", "Fast, thoughtful code", "Amharic and English", "Made with care", "Ready for mobile"]].map((item, i) => <span key={`${item}-${i}`} className="mx-5 whitespace-nowrap font-display text-sm text-cream/70">{item}<span className="ml-10 text-gold">✦</span></span>)}</div></div>

      <section id="play" className="scroll-mt-24 mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"><SectionHeading no="03" label="Live playground" title="Try it yourself." note="These are real interactions—not a static mockup. Each click updates React state."/><Reveal delay={120}><EnglishPlayground/></Reveal></section>

      <WebsiteBuilder language="en" />

      <section id="process" className="scroll-mt-24 border-y border-cream/10 bg-deep/50"><div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"><SectionHeading no="04" label="Process" title="How we’ll work together" note="Four clear steps from your first question to launch—with no surprises."/><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{steps.map(([no, title, desc, time], i) => <Reveal key={no} delay={i * 80}><article className="h-full border border-cream/10 p-6 transition duration-300 hover:-translate-y-1 hover:border-gold/40"><span className="font-mono text-sm text-gold">{no}</span><h3 className="mt-8 text-xl font-bold">{title}</h3><p className="mt-3 min-h-24 text-sm leading-7 text-mist">{desc}</p><p className="mt-5 border-t border-cream/10 pt-4 font-mono text-xs text-faint">{time}</p></article></Reveal>)}</div></div></section>

      <section id="code" className="scroll-mt-24 mx-auto grid max-w-7xl gap-12 px-5 py-20 md:px-8 md:py-28 lg:grid-cols-2"><Reveal><div><SectionHeading no="05" label="Under the hood" title="Readable code. Thoughtful work." note="Code should be understandable to people, not just machines. TypeScript supports Ethiopic characters, too—but clarity always comes first."/><ul className="space-y-4">{["Clean, easy-to-read code", "A clear component-based structure", "Ready for phones, tablets, and computers", "Fast performance, aiming for 90+ Lighthouse", "Proper support for Amharic (Ge’ez) text"].map((item) => <li key={item} className="flex items-center gap-3 text-sm text-mist"><span className="text-gold">✓</span>{item}</li>)}</ul></div></Reveal><Reveal delay={140}><div className="border border-cream/12 bg-deep transition-transform duration-500 hover:-translate-y-1"><div className="flex items-center justify-between border-b border-cream/10 px-4 py-3"><span className="font-mono text-xs text-mist">src/components/Greeting.tsx</span><span className="font-mono text-[10px] text-faint">TSX</span></div><pre className="overflow-x-auto whitespace-pre p-5 font-mono text-[11px] leading-7 text-cream/90 md:p-7 md:text-xs">{sampleCode}</pre><div className="flex justify-between border-t border-cream/10 px-5 py-3 font-mono text-xs"><span className="text-faint">16 lines · 0 errors</span><span className="text-leaf">✓ Clean and readable</span></div><div className="grid grid-cols-3 divide-x divide-cream/10 border-t border-cream/10 text-center">{[["19", "React"], ["5.9", "TypeScript"], ["4.1", "Tailwind"]].map(([value, label]) => <div key={label} className="py-4"><p className="font-latin text-xl font-bold">{value}</p><p className="text-xs text-faint">{label}</p></div>)}</div></div></Reveal></section>

      <section id="faq" className="scroll-mt-24 border-y border-cream/10 bg-deep/40"><div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 md:px-8 md:py-28 lg:grid-cols-[.8fr_1.2fr]"><Reveal><div><SectionHeading no="06" label="FAQ" title="Common questions"/><p className="text-sm text-mist">Have another question?</p><p className="mt-2 max-w-sm text-sm leading-7 text-faint">Send it over and I’ll answer directly—clearly and without jargon.</p><a className="mt-5 inline-block text-sm font-semibold text-gold hover:text-cream" href="#contact">Jump to contact ↗</a></div></Reveal><div className="space-y-3">{faqs.map(([question, answer], i) => <Reveal key={question} delay={i * 60}><article className="border border-cream/10 transition-colors hover:border-gold/40"><button onClick={() => setOpenFaq((current) => current === i ? -1 : i)} aria-expanded={openFaq === i} className="flex w-full items-center justify-between gap-4 p-5 text-left font-semibold"><span><span className="mr-3 font-mono text-xs text-gold">0{i + 1}</span>{question}</span><span className="text-gold">{openFaq === i ? "−" : "+"}</span></button>{openFaq === i && <p className="px-5 pb-5 pl-14 text-sm leading-7 text-mist">{answer}</p>}</article></Reveal>)}</div></div></section>
    </main>

    <footer id="contact" className="relative z-10 scroll-mt-24 border-t border-cream/10"><div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28"><Reveal><p className="font-mono text-[11px] font-semibold uppercase tracking-[.28em] text-gold">07 · Contact</p><div className="mt-5 grid gap-10 md:grid-cols-2 md:items-end"><div><h2 className="font-display text-5xl font-black md:text-7xl">Have a project<br/><span className="text-gold">in mind?</span></h2><a className="mt-8 inline-block text-2xl font-bold text-gold transition hover:translate-x-1 hover:text-cream" href="mailto:selam@kodtebib.et">Let’s talk →</a></div><div className="grid gap-5 text-sm text-mist sm:grid-cols-3 md:pb-2"><a href="mailto:selam@kodtebib.et" className="hover:text-gold"><span className="block text-xs text-faint">Email</span><span className="mt-2 block">selam@kodtebib.et</span></a><a href="#contact" className="hover:text-gold"><span className="block text-xs text-faint">Telegram</span><span className="mt-2 block">@kodtebib</span></a><div><span className="block text-xs text-faint">Location</span><span className="mt-2 block">Addis Ababa · Anywhere</span></div></div></div><div className="mt-16 flex flex-col justify-between gap-3 border-t border-cream/10 pt-5 text-xs text-faint sm:flex-row"><span>© {new Date().getFullYear()} Code Tebib · All rights reserved</span><span>Complete websites · React 19 · Tailwind CSS 4</span></div></Reveal></div></footer>
    <BackToTop/>
  </div>;
}
