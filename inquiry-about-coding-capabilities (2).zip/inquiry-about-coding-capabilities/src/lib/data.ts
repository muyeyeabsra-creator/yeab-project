/* ---------- የተርሚናል ኮድ ቁርጥራጮች (tokens) ---------- */
export type Tok = { t: string; c?: "k" | "s" | "f" | "c" | "p" };

export const SNIPPETS: Tok[][][] = [
  [
    [{ t: "// ጥያቄ፡ «ኮድ መጻፍ ለይ እንዴት ነህ?»", c: "c" }],
    [{ t: "const", c: "k" }, { t: " ገንቢ ", c: "f" }, { t: "= {", c: "p" }],
    [{ t: "  ስም", c: "f" }, { t: ": ", c: "p" }, { t: "\"ኮድ ጠቢብ\"", c: "s" }, { t: ",", c: "p" }],
    [
      { t: "  ቋንቋዎች", c: "f" },
      { t: ": [", c: "p" },
      { t: "\"React\"", c: "s" },
      { t: ", ", c: "p" },
      { t: "\"TypeScript\"", c: "s" },
      { t: ", ", c: "p" },
      { t: "\"Tailwind\"", c: "s" },
      { t: "],", c: "p" },
    ],
    [{ t: "  ደረጃ", c: "f" }, { t: ": ", c: "p" }, { t: "\"ዝግጁ\"", c: "s" }],
    [{ t: "};", c: "p" }],
    [],
    [{ t: "function", c: "k" }, { t: " ማሳያ", c: "f" }, { t: "() {", c: "p" }],
    [
      { t: "  return", c: "k" },
      { t: " <", c: "p" },
      { t: "ሙሉ፡ዌብሳይት", c: "k" },
      { t: " {", c: "p" },
      { t: "...ገንቢ", c: "f" },
      { t: "} />", c: "p" },
      { t: ";", c: "p" },
    ],
    [{ t: "}", c: "p" }],
  ],
  [
    [{ t: "// ከአንድ ጥያቄ → ሙሉ ድረ-ገጽ", c: "c" }],
    [
      { t: "async", c: "k" },
      { t: " function", c: "k" },
      { t: " ግንባታ", c: "f" },
      { t: "(", c: "p" },
      { t: "ሀሳብ", c: "f" },
      { t: ") {", c: "p" },
    ],
    [
      { t: "  const", c: "k" },
      { t: " ዲዛይን ", c: "f" },
      { t: "= ", c: "p" },
      { t: "await", c: "k" },
      { t: " አስብ", c: "f" },
      { t: "(", c: "p" },
      { t: "ሀሳብ", c: "f" },
      { t: ");", c: "p" },
    ],
    [
      { t: "  const", c: "k" },
      { t: " ኮድ ", c: "f" },
      { t: "= ", c: "p" },
      { t: "await", c: "k" },
      { t: " ጻፍ", c: "f" },
      { t: "(", c: "p" },
      { t: "ዲዛይን", c: "f" },
      { t: ");", c: "p" },
    ],
    [{ t: "  return", c: "k" }, { t: " አስጀምር", c: "f" }, { t: "(", c: "p" }, { t: "ኮድ", c: "f" }, { t: ");", c: "p" }],
    [{ t: "}", c: "p" }],
    [],
    [{ t: "ግንባታ", c: "f" }, { t: "(", c: "p" }, { t: "\"የእርስዎ ሀሳብ\"", c: "s" }, { t: ");", c: "p" }],
    [{ t: "// ✓ ውጤት፡ ይህች ገጽ — በቀጥታ ታያለች", c: "c" }],
  ],
];

/* ---------- ቴክኖሎጂ ማርኪ ---------- */
export const TECH = [
  "React",
  "TypeScript",
  "Tailwind CSS",
  "Node.js",
  "PostgreSQL",
  "GraphQL",
  "Vite",
  "Figma",
  "Git",
  "REST API",
  "Next.js",
  "Amharic UI",
];

export const PHRASES = [
  "ሙሉ ድረ-ገጽ",
  "ከአንድ ጥያቄ",
  "ፈጣን ኮድ",
  "በአማርኛ",
  "ዘመናዊ ዲዛይን",
  "ከልብ የተሰራ",
  "ለስልክ ዝግጁ",
];

/* ---------- አቅሞች ---------- */
export type Capability = {
  no: string;
  icon: "site" | "app" | "design" | "api" | "care";
  title: string;
  latin: string;
  desc: string;
  tags: string[];
};

export const CAPABILITIES: Capability[] = [
  {
    no: "01",
    icon: "site",
    title: "የንግድ ድረ-ገጾች",
    latin: "Websites",
    desc: "ፈጣን፣ ቆንጆ እና በማንኛውም መሣሪያ ላይ በትክክል የሚታይ መግለጫ እና የንግድ ገጽ።",
    tags: ["React", "Tailwind", "SEO"],
  },
  {
    no: "02",
    icon: "app",
    title: "ዌብ አፕሊኬሽኖች",
    latin: "Web Apps",
    desc: "ዳሽቦርድ፣ መደብር፣ የመግቢያ ሥርዓት እና ዳታቤዝ ያላቸው ሙሉ አፕሊኬሽኖች።",
    tags: ["TypeScript", "Node.js", "PostgreSQL"],
  },
  {
    no: "03",
    icon: "design",
    title: "UI / UX ዲዛይን",
    latin: "Design",
    desc: "ከሀሳብ እስከ ንድፍ — ቀለም፣ ፊደል እና አቀማመጥ በጥንቃቄ የተመረጠ።",
    tags: ["Figma", "Prototype", "Design System"],
  },
  {
    no: "04",
    icon: "api",
    title: "API እና ባክ-ኢንድ",
    latin: "Backend",
    desc: "ፈጣን፣ ደህንነቱ የተጠበቀ እና ለማደግ ዝግጁ የሆነ የሰርቨር ኮድ።",
    tags: ["REST", "GraphQL", "Auth"],
  },
  {
    no: "05",
    icon: "care",
    title: "ጥገና እና ፍጥነት",
    latin: "Care",
    desc: "ያለ ገጽህን ፍጥነት ማሻሻል፣ ስህተቶችን መፍታት እና ቀጣይ ድጋፍ ማድረግ።",
    tags: ["Performance", "A11y", "Support"],
  },
];

/* ---------- የስራ ናሙናዎች ---------- */
export type Project = {
  key: "buna" | "gebya" | "tera";
  letter: string;
  title: string;
  sub: string;
  year: string;
  tags: string[];
};

export const PROJECTS: Project[] = [
  {
    key: "buna",
    letter: "ቡ",
    title: "ቡና ቤት",
    sub: "ለአዲስ አበባ ካፌ የተሰራ የመስመር ላይ ምናሌ፣ ቦታ ማስያዣ እና ትዕዛዝ ሥርዓት።",
    year: "2025",
    tags: ["React", "Stripe", "CMS"],
  },
  {
    key: "gebya",
    letter: "ገ",
    title: "ገበያ ዳሽቦርድ",
    sub: "ሻጮች ሽያጫቸውን በቀጥታ የሚከታተሉበት የመቆጣጠሪያ ሰሌዳ።",
    year: "2025",
    tags: ["TypeScript", "Charts", "API"],
  },
  {
    key: "tera",
    letter: "ት",
    title: "ተራራ ትምህርት",
    sub: "ተማሪዎች ትምህርት የሚከታተሉበት እና መምህራን የሚያስተዳድሩበት ፖርታል።",
    year: "2024",
    tags: ["Next.js", "Auth", "PostgreSQL"],
  },
];

/* ---------- አሰራር ---------- */
export const STEPS = [
  {
    no: "01",
    title: "ማዳመጥ",
    desc: "በጥያቄህ እጀምራለሁ — ምን ዓይነት ድረ-ገጽ? ለማን? ዓላማህ ምንድን ነው?",
    time: "ቀን 1",
  },
  {
    no: "02",
    title: "ዲዛይን",
    desc: "ቀለም፣ ፊደል እና አቀማመጥ — ከመጻፍ በፊት መልክዑን በንድፍ እቀርጻለሁ።",
    time: "ቀን 2–3",
  },
  {
    no: "03",
    title: "ኮድ",
    desc: "React እና TypeScript — ንጹህ፣ ፈጣን፣ ለስልክም ለኮምፒውተርም የሚሆን።",
    time: "ሳምንት 1–2",
  },
  {
    no: "04",
    title: "ማስጀመር",
    desc: "ወደ ኢንተርኔት እለቅቀዋለሁ — ጎራ፣ ፍጥነት እና ቀጣይ ጥገና ጨምሮ።",
    time: "የመጨረሻ ቀን",
  },
];

/* ---------- ጥያቄዎች ---------- */
export const FAQS = [
  {
    q: "ኮድ መጻፍ ለይ እንዴት ነህ?",
    a: "በአጭሩ — በጣም ጥሩ! ይህች እያየኸት ያለህ ገጽ ሙሉ በሙሉ የተጻፈ ኮድ ናት፤ React 19፣ TypeScript እና Tailwind CSS 4 ተጠቅሜ ገንብቻታለሁ። ማንበብ የሚቻል፣ ለውጥ የሚቀልል እና ፈጣን ኮድ እጽፋለሁ።",
  },
  {
    q: "ሙሉ ዌብሳይት — ከፊት እስከ ጀርባ — መስራት ትችላለህ?",
    a: "አዎ። ፊት-ኢንድ (React፣ Tailwind)፣ ባክ-ኢንድ (Node.js፣ PostgreSQL)፣ የመግቢያ ሥርዓት፣ የመክፈያ ማገናኛ እና ወደ ኢንተርኔት ማስጀመር — ሁሉንም አካትቼ አደርጋለሁ። ከላይ ባለው «በቀጥታ ሞክር» ክፍል የቀጥታ ማሳያ ማየት ትችላለህ።",
  },
  {
    q: "ስራው ስንት ጊዜ ይወስዳል?",
    a: "አንድ ገጽ ያለው መግለጫ ድረ-ገጽ ከ2–3 ቀናት፤ መካከለኛ የንግድ ገጽ ከ1–2 ሳምንታት፤ ትልቅ ዌብ አፕሊኬሽን ደግሞ በዕቅዱ ይወሰናል። መጀመሪያ ሁልጊዜ ግልጽ የጊዜ ሰሌዳ እሰጣለሁ።",
  },
  {
    q: "ከዲዛይን ጀምሮ እስከ ማስጀመር ድረስ ታግዛለህ?",
    a: "አዎ — ሀሳብህን በማዳመጥ እጀምራለሁ፣ ቀለምና ፊደል እመርጣለሁ፣ ኮድ እጽፋለሁ፣ ጎራ እያዝላለሁ፣ ወደ ኢንተርኔት እለቅቃለሁ። ከዚያ በኋላም ጥገናና ድጋፍ አለ።",
  },
  {
    q: "እንዴት ልጀምር?",
    a: "ቀላል ነው — ወደ ታች ዘልለህ «እንነጋገር» የሚለውን ጠቅ አድርግ ወይም ጥያቄህን በቀጥታ ጻፍልኝ። «ሙሉ ዌብሳይት ስራልኝ» ብለህ ብትጠይቀኝ እንኳ ዛሬውኑ እጀምራለሁ።",
  },
];

/* ---------- ስታቲስቲክስ ---------- */
export const STATS = [
  { n: 5, suf: "", label: "የአገልግሎት አይነቶች" },
  { n: 2, suf: "", label: "ቋንቋዎች" },
  { n: 4, suf: "", label: "የዌብሳይት አይነቶች" },
  { n: 3, suf: "", label: "የቀለም ገጽታዎች" },
];
