export type Language = "am" | "en";

export const LANGUAGE_EVENT = "code-tebib-language-change";

export function getLanguage(): Language {
  try {
    return window.localStorage.getItem("code-tebib-language") === "en" ? "en" : "am";
  } catch {
    return "am";
  }
}

export function setLanguage(language: Language) {
  try {
    window.localStorage.setItem("code-tebib-language", language);
  } catch {
    // Keep the language switch working even when browser storage is restricted.
  }
  window.dispatchEvent(new CustomEvent(LANGUAGE_EVENT, { detail: language }));
}
